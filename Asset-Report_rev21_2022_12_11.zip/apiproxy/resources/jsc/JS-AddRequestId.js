  var payload = JSON.parse(context.getVariable("request.content"));
payload.FTrequestId = context.getVariable('FTrequestId');

context.setVariable("request.content", JSON.stringify(payload));