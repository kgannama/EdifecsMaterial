var oas={
  "swagger": "2.0",
  "info": {
    "description": "Get Asset Report from Plaid",
    "version": "1.0.0",
    "title": "Asset Report",
    "contact": {
      "email": "Yeshwanth.aendapally@firsttechfed.com"
    }
  },
  "host": "api.firsttechfed.com",
  "basePath": "/v1/assets",
  "schemes": [
    "https"
  ],
  "paths": {
    "/report": {
      "post": {
        "tags": [
          "report"
        ],
        "summary": "Retrieves Asset Report from Plaid ",
        "description": "",
        "operationId": "report",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "parameters": [
          {
            "in": "body",
            "name": "body",
            "description": "Retrieves Asset Report from Plaid",
            "required": true,
            "schema": {
              "$ref": "#/definitions/report"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/AssetReportResponse"
            }
          },
          "422": {
            "description": "Input Field Validation Failure.",
            "schema": {
              "$ref": "#/definitions/InputFieldValidationResponse"
            }
          },
          "429": {
            "description": "Exceeded quota limit.",
            "schema": {
              "$ref": "#/definitions/QuotaLimitValidationResponse"
            }
          },
          "500": {
            "description": "System Exceptions.",
            "schema": {
              "$ref": "#/definitions/Response500Error"
            }
          },
          "504": {
            "description": "Timeout.",
            "schema": {
              "$ref": "#/definitions/ResponseValidationTimeout"
            }
          }
        }
      }
    }
  },
  "definitions": {
    "report": {
      "type": "object",
      "required": [
        "webhook_type",
        "webhook_code",
        "asset_report_id"
      ],
      "properties": {
        "webhook_type": {
          "type": "string",
          "description": "Type of Webhook from Plaid.</br> Expected Value is ASSETS </br> Required field webhook_type is missing or invalid"
        },
        "webhook_code": {
          "type": "string",
          "enum": [
            "PRODUCT_READY",
            "ERROR"
          ],
          "description": "Webhook code </br> Expected Values are PRODUCT_READY,ERROR </br> Required field webhook_code is missing or invalid"
        },
        "asset_report_id": {
          "type": "string",
          "description": "Unique Asset report ID to pull the asset report</br> GUID Validation</br> Required field asset_report_id is missing or invalid."
        },
        "requestId": {
          "type": "string",
          "description": "Unique identifier for each API call"
        },
        "error": {
          "type": "object",
          "description": "Reconciliation data",
          "properties": {
            "display_message": {
              "type": "string",
              "description": "A user-friendly representation of the error code. null if the error is not related to user action.</br>"
            },
            "error_code": {
              "type": "string",
              "description": "Errorcode Specifying error</br>"
            },
            "error_message": {
              "type": "string",
              "description": "Error Message Description</br>"
            },
            "error_type": {
              "type": "string",
              "enum": [
                "INVALID_REQUEST",
                "INVALID_RESULT",
                "INVALID_INPUT",
                "INSTITUTION_ERROR",
                "RATE_LIMIT_EXCEEDED",
                "API_ERROR",
                "ITEM_ERROR",
                "ASSET_REPORT_ERROR",
                "RECAPTCHA_ERROR",
                "OAUTH_ERROR",
                "PAYMENT_ERROR",
                "BANK_TRANSFER_ERROR",
                "INCOME_VERIFICATION_ERROR"
              ],
              "description": "Type of Errors </br>"
            },
            "request_id": {
              "type": "string",
              "description": "Unique Id to troubleshoot the error"
            }
          }
        }
      }
    },
    "AssetReportResponse": {
      "type": "object",
      "properties": {
        "statusMessage": {
          "type": "string",
          "description": "SuccessMessage to acknowledge webhook request"
        },
        "requestId": {
          "type": "string",
          "description": "Unique identifier for each API call"
        },
        "statusCode": {
          "type": "integer",
          "description": "status code to acknowledge the request",
          "enum": [
            200
          ]
        }
      }
    },
    "Response500Error": {
      "type": "object",
      "properties": {
        "statusMessage": {
          "type": "string"
        },
        "requestId": {
          "type": "string",
          "description": "Unique identifier for each API call"
        },
        "statusCode": {
          "type": "integer",
          "description": "System Exceptions. Partner can retry and if the issue still persist, should follow the First Tech Support process identified for the partner.",
          "enum": [
            500
          ]
        }
      }
    },
    "ResponseValidationTimeout": {
      "type": "object",
      "properties": {
        "statusCode": {
          "type": "integer",
          "description": "Error Code",
          "enum": [
            504
          ]
        },
        "statusMessage": {
          "type": "string",
          "description": "Status message",
          "enum": [
            "Request Timed Out"
          ]
        }
      }
    },
    "QuotaLimitValidationResponse": {
      "type": "object",
      "properties": {
        "statusCode": {
          "type": "integer",
          "description": "Error Code",
          "enum": [
            429
          ]
        },
        "statusMessage": {
          "type": "string",
          "description": "Status message",
          "enum": [
            "Too many requests"
          ]
        },
        "faultName": {
          "type": "string",
          "enum": [
            "Quota Limit Exceeded"
          ]
        },
        "error": {
          "type": "string",
          "enum": [
            "Rate limit quota violation. Quota limit exceeded"
          ]
        }
      }
    },
    "InputFieldValidationResponse": {
      "type": "object",
      "properties": {
        "statusCode": {
          "type": "integer",
          "description": "Code",
          "enum": [
            422
          ]
        },
        "statusMessage": {
          "type": "string",
          "description": "Error Message",
          "enum": [
            "Validation Failure"
          ]
        },
        "errors": {
          "description": "Collection of erros",
          "items": {
            "$ref": "#/definitions/errorResponses"
          }
        }
      }
    },
    "errorResponses": {
      "type": "object",
      "properties": {
        "code": {
          "type": "integer"
        },
        "fields": {
          "type": "string",
          "description": "Field name that is resulting in the error"
        },
        "message": {
          "type": "string",
          "description": "Error Message"
        }
      }
    }
  }
}