 try {
    // modify the payload of a JWKS to remove the "use" fields in each EC key
    var payload =  JSON.parse('{ "keys":[' + context.getVariable('key') + '] }');
    payload.keys.forEach(function(jwk) { 
        if (jwk.use && jwk.kty == 'EC') { 
            delete jwk.use; 
        }
    });
    //delete payload["use"];
    context.setVariable('key', JSON.stringify(payload)); 
    
 }
 catch (err) {
	context.setVariable("EH_ErrorDescription",'Invalid Key');
    context.setVariable('javascript.errorMessage', err);
    throw err;
 }
 