 ! function(a, b) {
    "function" == typeof define && define.amd ? define([], b) : "undefined" != typeof module && module.exports ? module.exports = b() : a.tv4 = b()
}(this, function() {
    function a(a) {
        return encodeURI(a).replace(/%25[0-9][0-9]/g, function(a) {
            return "%" + a.substring(3)
        })
    }

    function b(b) {
        var c = "";
        m[b.charAt(0)] && (c = b.charAt(0), b = b.substring(1));
        var d = "",
            e = "",
            f = !0,
            g = !1,
            h = !1;
        "+" === c ? f = !1 : "." === c ? (e = ".", d = ".") : "/" === c ? (e = "/", d = "/") : "#" === c ? (e = "#", f = !1) : ";" === c ? (e = ";", d = ";", g = !0, h = !0) : "?" === c ? (e = "?", d = "&", g = !0) : "&" === c && (e = "&", d = "&", g = !0);
        for (var i = [], j = b.split(","), k = [], l = {}, o = 0; o < j.length; o++) {
            var p = j[o],
                q = null;
            if (-1 !== p.indexOf(":")) {
                var r = p.split(":");
                p = r[0], q = parseInt(r[1], 10)
            }
            for (var s = {}; n[p.charAt(p.length - 1)];) s[p.charAt(p.length - 1)] = !0, p = p.substring(0, p.length - 1);
            var t = {
                truncate: q,
                name: p,
                suffices: s
            };
            k.push(t), l[p] = t, i.push(p)
        }
        var u = function(b) {
            for (var c = "", i = 0, j = 0; j < k.length; j++) {
                var l = k[j],
                    m = b(l.name);
                if (null === m || void 0 === m || Array.isArray(m) && 0 === m.length || "object" == typeof m && 0 === Object.keys(m).length) i++;
                else if (c += j === i ? e : d || ",", Array.isArray(m)) {
                    g && (c += l.name + "=");
                    for (var n = 0; n < m.length; n++) n > 0 && (c += l.suffices["*"] ? d || "," : ",", l.suffices["*"] && g && (c += l.name + "=")), c += f ? encodeURIComponent(m[n]).replace(/!/g, "%21") : a(m[n])
                } else if ("object" == typeof m) {
                    g && !l.suffices["*"] && (c += l.name + "=");
                    var o = !0;
                    for (var p in m) o || (c += l.suffices["*"] ? d || "," : ","), o = !1, c += f ? encodeURIComponent(p).replace(/!/g, "%21") : a(p), c += l.suffices["*"] ? "=" : ",", c += f ? encodeURIComponent(m[p]).replace(/!/g, "%21") : a(m[p])
                } else g && (c += l.name, h && "" === m || (c += "=")), null != l.truncate && (m = m.substring(0, l.truncate)), c += f ? encodeURIComponent(m).replace(/!/g, "%21") : a(m)
            }
            return c
        };
        return u.varNames = i, {
            prefix: e,
            substitution: u
        }
    }

    function c(a) {
        if (!(this instanceof c)) return new c(a);
        for (var d = a.split("{"), e = [d.shift()], f = [], g = [], h = []; d.length > 0;) {
            var i = d.shift(),
                j = i.split("}")[0],
                k = i.substring(j.length + 1),
                l = b(j);
            g.push(l.substitution), f.push(l.prefix), e.push(k), h = h.concat(l.substitution.varNames)
        }
        this.fill = function(a) {
            for (var b = e[0], c = 0; c < g.length; c++) {
                var d = g[c];
                b += d(a), b += e[c + 1]
            }
            return b
        }, this.varNames = h, this.template = a
    }

    function d(a, b) {
        if (a === b) return !0;
        if (a && b && "object" == typeof a && "object" == typeof b) {
            if (Array.isArray(a) !== Array.isArray(b)) return !1;
            if (Array.isArray(a)) {
                if (a.length !== b.length) return !1;
                for (var c = 0; c < a.length; c++)
                    if (!d(a[c], b[c])) return !1
            } else {
                var e;
                for (e in a)
                    if (void 0 === b[e] && void 0 !== a[e]) return !1;
                for (e in b)
                    if (void 0 === a[e] && void 0 !== b[e]) return !1;
                for (e in a)
                    if (!d(a[e], b[e])) return !1
            }
            return !0
        }
        return !1
    }

    function e(a) {
        var b = String(a).replace(/^\s+|\s+$/g, "").match(/^([^:\/?#]+:)?(\/\/(?:[^:@]*(?::[^:@]*)?@)?(([^:\/?#]*)(?::(\d*))?))?([^?#]*)(\?[^#]*)?(#[\s\S]*)?/);
        return b ? {
            href: b[0] || "",
            protocol: b[1] || "",
            authority: b[2] || "",
            host: b[3] || "",
            hostname: b[4] || "",
            port: b[5] || "",
            pathname: b[6] || "",
            search: b[7] || "",
            hash: b[8] || ""
        } : null
    }

    function f(a, b) {
        function c(a) {
            var b = [];
            return a.replace(/^(\.\.?(\/|$))+/, "").replace(/\/(\.(\/|$))+/g, "/").replace(/\/\.\.$/, "/../").replace(/\/?[^\/]*/g, function(a) {
                "/.." === a ? b.pop() : b.push(a)
            }), b.join("").replace(/^\//, "/" === a.charAt(0) ? "/" : "")
        }
        return b = e(b || ""), a = e(a || ""), b && a ? (b.protocol || a.protocol) + (b.protocol || b.authority ? b.authority : a.authority) + c(b.protocol || b.authority || "/" === b.pathname.charAt(0) ? b.pathname : b.pathname ? (a.authority && !a.pathname ? "/" : "") + a.pathname.slice(0, a.pathname.lastIndexOf("/") + 1) + b.pathname : a.pathname) + (b.protocol || b.authority || b.pathname ? b.search : b.search || a.search) + b.hash : null
    }

    function g(a) {
        return a.split("#")[0]
    }

    function h(a, b) {
        if (a && "object" == typeof a)
            if (void 0 === b ? b = a.id : "string" == typeof a.id && (b = f(b, a.id), a.id = b), Array.isArray(a))
                for (var c = 0; c < a.length; c++) h(a[c], b);
            else {
                "string" == typeof a.$ref && (a.$ref = f(b, a.$ref));
                for (var d in a) "enum" !== d && h(a[d], b)
            }
    }

    function i(a) {
        a = a || "en";
        var b = v[a];
        return function(a) {
            var c = b[a.code] || u[a.code];
            if ("string" != typeof c) return "Unknown error code " + a.code + ": " + JSON.stringify(a.messageParams);
            var d = a.params;
            return c.replace(/\{([^{}]*)\}/g, function(a, b) {
                var c = d[b];
                return "string" == typeof c || "number" == typeof c ? c : a
            })
        }
    }

    function j(a, b, c, d, e) {
        if (Error.call(this), void 0 === a) throw new Error("No error code supplied: " + d);
        this.message = "", this.params = b, this.code = a, this.dataPath = c || "", this.schemaPath = d || "", this.subErrors = e || null;
        var f = new Error(this.message);
        if (this.stack = f.stack || f.stacktrace, !this.stack) try {
            throw f
        } catch (f) {
            this.stack = f.stack || f.stacktrace
        }
    }

    function k(a, b) {
        if (b.substring(0, a.length) === a) {
            var c = b.substring(a.length);
            if (b.length > 0 && "/" === b.charAt(a.length - 1) || "#" === c.charAt(0) || "?" === c.charAt(0)) return !0
        }
        return !1
    }

    function l(a) {
        var b, c, d = new o,
            e = {
                setErrorReporter: function(a) {
                    return "string" == typeof a ? this.language(a) : (c = a, !0)
                },
                addFormat: function() {
                    d.addFormat.apply(d, arguments)
                },
                language: function(a) {
                    return a ? (v[a] || (a = a.split("-")[0]), v[a] ? (b = a, a) : !1) : b
                },
                addLanguage: function(a, b) {
                    var c;
                    for (c in r) b[c] && !b[r[c]] && (b[r[c]] = b[c]);
                    var d = a.split("-")[0];
                    if (v[d]) {
                        v[a] = Object.create(v[d]);
                        for (c in b) "undefined" == typeof v[d][c] && (v[d][c] = b[c]), v[a][c] = b[c]
                    } else v[a] = b, v[d] = b;
                    return this
                },
                freshApi: function(a) {
                    var b = l();
                    return a && b.language(a), b
                },
                validate: function(a, e, f, g) {
                    var h = i(b),
                        j = c ? function(a, b, d) {
                            return c(a, b, d) || h(a, b, d)
                        } : h,
                        k = new o(d, !1, j, f, g);
                    "string" == typeof e && (e = {
                        $ref: e
                    }), k.addSchema("", e);
                    var l = k.validateAll(a, e, null, null, "");
                    return !l && g && (l = k.banUnknownProperties(a, e)), this.error = l, this.missing = k.missing, this.valid = null === l, this.valid
                },
                validateResult: function() {
                    var a = {};
                    return this.validate.apply(a, arguments), a
                },
                validateMultiple: function(a, e, f, g) {
                    var h = i(b),
                        j = c ? function(a, b, d) {
                            return c(a, b, d) || h(a, b, d)
                        } : h,
                        k = new o(d, !0, j, f, g);
                    "string" == typeof e && (e = {
                        $ref: e
                    }), k.addSchema("", e), k.validateAll(a, e, null, null, ""), g && k.banUnknownProperties(a, e);
                    var l = {};
                    return l.errors = k.errors, l.missing = k.missing, l.valid = 0 === l.errors.length, l
                },
                addSchema: function() {
                    return d.addSchema.apply(d, arguments)
                },
                getSchema: function() {
                    return d.getSchema.apply(d, arguments)
                },
                getSchemaMap: function() {
                    return d.getSchemaMap.apply(d, arguments)
                },
                getSchemaUris: function() {
                    return d.getSchemaUris.apply(d, arguments)
                },
                getMissingUris: function() {
                    return d.getMissingUris.apply(d, arguments)
                },
                dropSchemas: function() {
                    d.dropSchemas.apply(d, arguments)
                },
                defineKeyword: function() {
                    d.defineKeyword.apply(d, arguments)
                },
                defineError: function(a, b, c) {
                    if ("string" != typeof a || !/^[A-Z]+(_[A-Z]+)*$/.test(a)) throw new Error("Code name must be a string in UPPER_CASE_WITH_UNDERSCORES");
                    if ("number" != typeof b || b % 1 !== 0 || 1e4 > b) throw new Error("Code number must be an integer > 10000");
                    if ("undefined" != typeof r[a]) throw new Error("Error already defined: " + a + " as " + r[a]);
                    if ("undefined" != typeof s[b]) throw new Error("Error code already used: " + s[b] + " as " + b);
                    r[a] = b, s[b] = a, u[a] = u[b] = c;
                    for (var d in v) {
                        var e = v[d];
                        e[a] && (e[b] = e[b] || e[a])
                    }
                },
                reset: function() {
                    d.reset(), this.error = null, this.missing = [], this.valid = !0
                },
                missing: [],
                error: null,
                valid: !0,
                normSchema: h,
                resolveUrl: f,
                getDocumentUri: g,
                errorCodes: r
            };
        return e.language(a || "en"), e
    }
    Object.keys || (Object.keys = function() {
        var a = Object.prototype.hasOwnProperty,
            b = !{
                toString: null
            }.propertyIsEnumerable("toString"),
            c = ["toString", "toLocaleString", "valueOf", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "constructor"],
            d = c.length;
        return function(e) {
            if ("object" != typeof e && "function" != typeof e || null === e) throw new TypeError("Object.keys called on non-object");
            var f = [];
            for (var g in e) a.call(e, g) && f.push(g);
            if (b)
                for (var h = 0; d > h; h++) a.call(e, c[h]) && f.push(c[h]);
            return f
        }
    }()), Object.create || (Object.create = function() {
        function a() {}
        return function(b) {
            if (1 !== arguments.length) throw new Error("Object.create implementation only accepts one parameter.");
            return a.prototype = b, new a
        }
    }()), Array.isArray || (Array.isArray = function(a) {
        return "[object Array]" === Object.prototype.toString.call(a)
    }), Array.prototype.indexOf || (Array.prototype.indexOf = function(a) {
        if (null === this) throw new TypeError;
        var b = Object(this),
            c = b.length >>> 0;
        if (0 === c) return -1;
        var d = 0;
        if (arguments.length > 1 && (d = Number(arguments[1]), d !== d ? d = 0 : 0 !== d && d !== 1 / 0 && d !== -(1 / 0) && (d = (d > 0 || -1) * Math.floor(Math.abs(d)))), d >= c) return -1;
        for (var e = d >= 0 ? d : Math.max(c - Math.abs(d), 0); c > e; e++)
            if (e in b && b[e] === a) return e;
        return -1
    }), Object.isFrozen || (Object.isFrozen = function(a) {
        for (var b = "tv4_test_frozen_key"; a.hasOwnProperty(b);) b += Math.random();
        try {
            return a[b] = !0, delete a[b], !1
        } catch (c) {
            return !0
        }
    });
    var m = {
            "+": !0,
            "#": !0,
            ".": !0,
            "/": !0,
            ";": !0,
            "?": !0,
            "&": !0
        },
        n = {
            "*": !0
        };
    c.prototype = {
        toString: function() {
            return this.template
        },
        fillFromObject: function(a) {
            return this.fill(function(b) {
                return a[b]
            })
        }
    };
    var o = function(a, b, c, d, e) {
        if (this.missing = [], this.missingMap = {}, this.formatValidators = a ? Object.create(a.formatValidators) : {}, this.schemas = a ? Object.create(a.schemas) : {}, this.collectMultiple = b, this.errors = [], this.handleError = b ? this.collectError : this.returnError, d && (this.checkRecursive = !0, this.scanned = [], this.scannedFrozen = [], this.scannedFrozenSchemas = [], this.scannedFrozenValidationErrors = [], this.validatedSchemasKey = "tv4_validation_id", this.validationErrorsKey = "tv4_validation_errors_id"), e && (this.trackUnknownProperties = !0, this.knownPropertyPaths = {}, this.unknownPropertyPaths = {}), this.errorReporter = c || i("en"), "string" == typeof this.errorReporter) throw new Error("debug");
        if (this.definedKeywords = {}, a)
            for (var f in a.definedKeywords) this.definedKeywords[f] = a.definedKeywords[f].slice(0)
    };
    o.prototype.defineKeyword = function(a, b) {
        this.definedKeywords[a] = this.definedKeywords[a] || [], this.definedKeywords[a].push(b)
    }, o.prototype.createError = function(a, b, c, d, e, f, g) {
        var h = new j(a, b, c, d, e);
        return h.message = this.errorReporter(h, f, g), h
    }, o.prototype.returnError = function(a) {
        return a
    }, o.prototype.collectError = function(a) {
        return a && this.errors.push(a), null
    }, o.prototype.prefixErrors = function(a, b, c) {
        for (var d = a; d < this.errors.length; d++) this.errors[d] = this.errors[d].prefixWith(b, c);
        return this
    }, o.prototype.banUnknownProperties = function(a, b) {
        for (var c in this.unknownPropertyPaths) {
            var d = this.createError(r.UNKNOWN_PROPERTY, {
                    path: c
                }, c, "", null, a, b),
                e = this.handleError(d);
            if (e) return e
        }
        return null
    }, o.prototype.addFormat = function(a, b) {
        if ("object" == typeof a) {
            for (var c in a) this.addFormat(c, a[c]);
            return this
        }
        this.formatValidators[a] = b
    }, o.prototype.resolveRefs = function(a, b) {
        if (void 0 !== a.$ref) {
            if (b = b || {}, b[a.$ref]) return this.createError(r.CIRCULAR_REFERENCE, {
                urls: Object.keys(b).join(", ")
            }, "", "", null, void 0, a);
            b[a.$ref] = !0, a = this.getSchema(a.$ref, b)
        }
        return a
    }, o.prototype.getSchema = function(a, b) {
        var c;
        if (void 0 !== this.schemas[a]) return c = this.schemas[a], this.resolveRefs(c, b);
        var d = a,
            e = "";
        if (-1 !== a.indexOf("#") && (e = a.substring(a.indexOf("#") + 1), d = a.substring(0, a.indexOf("#"))), "object" == typeof this.schemas[d]) {
            c = this.schemas[d];
            var f = decodeURIComponent(e);
            if ("" === f) return this.resolveRefs(c, b);
            if ("/" !== f.charAt(0)) return void 0;
            for (var g = f.split("/").slice(1), h = 0; h < g.length; h++) {
                var i = g[h].replace(/~1/g, "/").replace(/~0/g, "~");
                if (void 0 === c[i]) {
                    c = void 0;
                    break
                }
                c = c[i]
            }
            if (void 0 !== c) return this.resolveRefs(c, b)
        }
        void 0 === this.missing[d] && (this.missing.push(d), this.missing[d] = d, this.missingMap[d] = d)
    }, o.prototype.searchSchemas = function(a, b) {
        if (Array.isArray(a))
            for (var c = 0; c < a.length; c++) this.searchSchemas(a[c], b);
        else if (a && "object" == typeof a) {
            "string" == typeof a.id && k(b, a.id) && void 0 === this.schemas[a.id] && (this.schemas[a.id] = a);
            for (var d in a)
                if ("enum" !== d)
                    if ("object" == typeof a[d]) this.searchSchemas(a[d], b);
                    else if ("$ref" === d) {
                var e = g(a[d]);
                e && void 0 === this.schemas[e] && void 0 === this.missingMap[e] && (this.missingMap[e] = e)
            }
        }
    }, o.prototype.addSchema = function(a, b) {
        if ("string" != typeof a || "undefined" == typeof b) {
            if ("object" != typeof a || "string" != typeof a.id) return;
            b = a, a = b.id
        }
        a === g(a) + "#" && (a = g(a)), this.schemas[a] = b, delete this.missingMap[a], h(b, a), this.searchSchemas(b, a)
    }, o.prototype.getSchemaMap = function() {
        var a = {};
        for (var b in this.schemas) a[b] = this.schemas[b];
        return a
    }, o.prototype.getSchemaUris = function(a) {
        var b = [];
        for (var c in this.schemas)(!a || a.test(c)) && b.push(c);
        return b
    }, o.prototype.getMissingUris = function(a) {
        var b = [];
        for (var c in this.missingMap)(!a || a.test(c)) && b.push(c);
        return b
    }, o.prototype.dropSchemas = function() {
        this.schemas = {}, this.reset()
    }, o.prototype.reset = function() {
        this.missing = [], this.missingMap = {}, this.errors = []
    }, o.prototype.validateAll = function(a, b, c, d, e) {
        var f;
        if (b = this.resolveRefs(b), !b) return null;
        if (b instanceof j) return this.errors.push(b), b;
        var g, h = this.errors.length,
            i = null,
            k = null;
        if (this.checkRecursive && a && "object" == typeof a) {
            if (f = !this.scanned.length, a[this.validatedSchemasKey]) {
                var l = a[this.validatedSchemasKey].indexOf(b);
                if (-1 !== l) return this.errors = this.errors.concat(a[this.validationErrorsKey][l]), null
            }
            if (Object.isFrozen(a) && (g = this.scannedFrozen.indexOf(a), -1 !== g)) {
                var m = this.scannedFrozenSchemas[g].indexOf(b);
                if (-1 !== m) return this.errors = this.errors.concat(this.scannedFrozenValidationErrors[g][m]), null
            }
            if (this.scanned.push(a), Object.isFrozen(a)) - 1 === g && (g = this.scannedFrozen.length, this.scannedFrozen.push(a), this.scannedFrozenSchemas.push([])), i = this.scannedFrozenSchemas[g].length, this.scannedFrozenSchemas[g][i] = b, this.scannedFrozenValidationErrors[g][i] = [];
            else {
                if (!a[this.validatedSchemasKey]) try {
                    Object.defineProperty(a, this.validatedSchemasKey, {
                        value: [],
                        configurable: !0
                    }), Object.defineProperty(a, this.validationErrorsKey, {
                        value: [],
                        configurable: !0
                    })
                } catch (n) {
                    a[this.validatedSchemasKey] = [], a[this.validationErrorsKey] = []
                }
                k = a[this.validatedSchemasKey].length, a[this.validatedSchemasKey][k] = b, a[this.validationErrorsKey][k] = []
            }
        }
        var o = this.errors.length,
            p = this.validateBasic(a, b, e) || this.validateNumeric(a, b, e) || this.validateString(a, b, e) || this.validateArray(a, b, e) || this.validateObject(a, b, e) || this.validateCombinations(a, b, e) || this.validateHypermedia(a, b, e) || this.validateFormat(a, b, e) || this.validateDefinedKeywords(a, b, e) || null;
        if (f) {
            for (; this.scanned.length;) {
                var q = this.scanned.pop();
                delete q[this.validatedSchemasKey]
            }
            this.scannedFrozen = [], this.scannedFrozenSchemas = []
        }
        if (p || o !== this.errors.length)
            for (; c && c.length || d && d.length;) {
                var r = c && c.length ? "" + c.pop() : null,
                    s = d && d.length ? "" + d.pop() : null;
                p && (p = p.prefixWith(r, s)), this.prefixErrors(o, r, s)
            }
        return null !== i ? this.scannedFrozenValidationErrors[g][i] = this.errors.slice(h) : null !== k && (a[this.validationErrorsKey][k] = this.errors.slice(h)), this.handleError(p)
    }, o.prototype.validateFormat = function(a, b) {
        if ("string" != typeof b.format || !this.formatValidators[b.format]) return null;
        var c = this.formatValidators[b.format].call(null, a, b);
        return "string" == typeof c || "number" == typeof c ? this.createError(r.FORMAT_CUSTOM, {
            message: c
        }, "", "/format", null, a, b) : c && "object" == typeof c ? this.createError(r.FORMAT_CUSTOM, {
            message: c.message || "?"
        }, c.dataPath || "", c.schemaPath || "/format", null, a, b) : null
    }, o.prototype.validateDefinedKeywords = function(a, b, c) {
        for (var d in this.definedKeywords)
            if ("undefined" != typeof b[d])
                for (var e = this.definedKeywords[d], f = 0; f < e.length; f++) {
                    var g = e[f],
                        h = g(a, b[d], b, c);
                    if ("string" == typeof h || "number" == typeof h) return this.createError(r.KEYWORD_CUSTOM, {
                        key: d,
                        message: h
                    }, "", "", null, a, b).prefixWith(null, d);
                    if (h && "object" == typeof h) {
                        var i = h.code;
                        if ("string" == typeof i) {
                            if (!r[i]) throw new Error("Undefined error code (use defineError): " + i);
                            i = r[i]
                        } else "number" != typeof i && (i = r.KEYWORD_CUSTOM);
                        var j = "object" == typeof h.message ? h.message : {
                                key: d,
                                message: h.message || "?"
                            },
                            k = h.schemaPath || "/" + d.replace(/~/g, "~0").replace(/\//g, "~1");
                        return this.createError(i, j, h.dataPath || null, k, null, a, b)
                    }
                }
        return null
    }, o.prototype.validateBasic = function(a, b, c) {
        var d;
        return (d = this.validateType(a, b, c)) ? d.prefixWith(null, "type") : (d = this.validateEnum(a, b, c)) ? d.prefixWith(null, "type") : null
    }, o.prototype.validateType = function(a, b) {
        if (void 0 === b.type) return null;
        var c = typeof a;
        null === a ? c = "null" : Array.isArray(a) && (c = "array");
        var d = b.type;
        Array.isArray(d) || (d = [d]);
        for (var e = 0; e < d.length; e++) {
            var f = d[e];
            if (f === c || "integer" === f && "number" === c && a % 1 === 0) return null
        }
        return this.createError(r.INVALID_TYPE, {
            type: c,
            expected: d.join("/")
        }, "", "", null, a, b)
    }, o.prototype.validateEnum = function(a, b) {
        if (void 0 === b["enum"]) return null;
        for (var c = 0; c < b["enum"].length; c++) {
            var e = b["enum"][c];
            if (d(a, e)) return null
        }
        return this.createError(r.ENUM_MISMATCH, {
            value: "undefined" != typeof JSON ? JSON.stringify(a) : a
        }, "", "", null, a, b)
    }, o.prototype.validateNumeric = function(a, b, c) {
        return this.validateMultipleOf(a, b, c) || this.validateMinMax(a, b, c) || this.validateNaN(a, b, c) || null
    };
    var p = Math.pow(2, -51),
        q = 1 - p;
    o.prototype.validateMultipleOf = function(a, b) {
        var c = b.multipleOf || b.divisibleBy;
        if (void 0 === c) return null;
        if ("number" == typeof a) {
            var d = a / c % 1;
            if (d >= p && q > d) return this.createError(r.NUMBER_MULTIPLE_OF, {
                value: a,
                multipleOf: c
            }, "", "", null, a, b)
        }
        return null
    }, o.prototype.validateMinMax = function(a, b) {
        if ("number" != typeof a) return null;
        if (void 0 !== b.minimum) {
            if (a < b.minimum) return this.createError(r.NUMBER_MINIMUM, {
                value: a,
                minimum: b.minimum
            }, "", "/minimum", null, a, b);
            if (b.exclusiveMinimum && a === b.minimum) return this.createError(r.NUMBER_MINIMUM_EXCLUSIVE, {
                value: a,
                minimum: b.minimum
            }, "", "/exclusiveMinimum", null, a, b)
        }
        if (void 0 !== b.maximum) {
            if (a > b.maximum) return this.createError(r.NUMBER_MAXIMUM, {
                value: a,
                maximum: b.maximum
            }, "", "/maximum", null, a, b);
            if (b.exclusiveMaximum && a === b.maximum) return this.createError(r.NUMBER_MAXIMUM_EXCLUSIVE, {
                value: a,
                maximum: b.maximum
            }, "", "/exclusiveMaximum", null, a, b)
        }
        return null
    }, o.prototype.validateNaN = function(a, b) {
        return "number" != typeof a ? null : isNaN(a) === !0 || a === 1 / 0 || a === -(1 / 0) ? this.createError(r.NUMBER_NOT_A_NUMBER, {
            value: a
        }, "", "/type", null, a, b) : null
    }, o.prototype.validateString = function(a, b, c) {
        return this.validateStringLength(a, b, c) || this.validateStringPattern(a, b, c) || null
    }, o.prototype.validateStringLength = function(a, b) {
        return "string" != typeof a ? null : void 0 !== b.minLength && a.length < b.minLength ? this.createError(r.STRING_LENGTH_SHORT, {
            length: a.length,
            minimum: b.minLength
        }, "", "/minLength", null, a, b) : void 0 !== b.maxLength && a.length > b.maxLength ? this.createError(r.STRING_LENGTH_LONG, {
            length: a.length,
            maximum: b.maxLength
        }, "", "/maxLength", null, a, b) : null
    }, o.prototype.validateStringPattern = function(a, b) {
        if ("string" != typeof a || "string" != typeof b.pattern && !(b.pattern instanceof RegExp)) return null;
        var c;
        if (b.pattern instanceof RegExp) c = b.pattern;
        else {
            var d, e = "",
                f = b.pattern.match(/^\/(.+)\/([img]*)$/);
            f ? (d = f[1], e = f[2]) : d = b.pattern, c = new RegExp(d, e)
        }
        return c.test(a) ? null : this.createError(r.STRING_PATTERN, {
            pattern: b.pattern
        }, "", "/pattern", null, a, b)
    }, o.prototype.validateArray = function(a, b, c) {
        return Array.isArray(a) ? this.validateArrayLength(a, b, c) || this.validateArrayUniqueItems(a, b, c) || this.validateArrayItems(a, b, c) || null : null
    }, o.prototype.validateArrayLength = function(a, b) {
        var c;
        return void 0 !== b.minItems && a.length < b.minItems && (c = this.createError(r.ARRAY_LENGTH_SHORT, {
            length: a.length,
            minimum: b.minItems
        }, "", "/minItems", null, a, b), this.handleError(c)) ? c : void 0 !== b.maxItems && a.length > b.maxItems && (c = this.createError(r.ARRAY_LENGTH_LONG, {
            length: a.length,
            maximum: b.maxItems
        }, "", "/maxItems", null, a, b), this.handleError(c)) ? c : null
    }, o.prototype.validateArrayUniqueItems = function(a, b) {
        if (b.uniqueItems)
            for (var c = 0; c < a.length; c++)
                for (var e = c + 1; e < a.length; e++)
                    if (d(a[c], a[e])) {
                        var f = this.createError(r.ARRAY_UNIQUE, {
                            match1: c,
                            match2: e
                        }, "", "/uniqueItems", null, a, b);
                        if (this.handleError(f)) return f
                    } return null
    }, o.prototype.validateArrayItems = function(a, b, c) {
        if (void 0 === b.items) return null;
        var d, e;
        if (Array.isArray(b.items)) {
            for (e = 0; e < a.length; e++)
                if (e < b.items.length) {
                    if (d = this.validateAll(a[e], b.items[e], [e], ["items", e], c + "/" + e)) return d
                } else if (void 0 !== b.additionalItems)
                if ("boolean" == typeof b.additionalItems) {
                    if (!b.additionalItems && (d = this.createError(r.ARRAY_ADDITIONAL_ITEMS, {}, "/" + e, "/additionalItems", null, a, b), this.handleError(d))) return d
                } else if (d = this.validateAll(a[e], b.additionalItems, [e], ["additionalItems"], c + "/" + e)) return d
        } else
            for (e = 0; e < a.length; e++)
                if (d = this.validateAll(a[e], b.items, [e], ["items"], c + "/" + e)) return d;
        return null
    }, o.prototype.validateObject = function(a, b, c) {
        return "object" != typeof a || null === a || Array.isArray(a) ? null : this.validateObjectMinMaxProperties(a, b, c) || this.validateObjectRequiredProperties(a, b, c) || this.validateObjectProperties(a, b, c) || this.validateObjectDependencies(a, b, c) || null
    }, o.prototype.validateObjectMinMaxProperties = function(a, b) {
        var c, d = Object.keys(a);
        return void 0 !== b.minProperties && d.length < b.minProperties && (c = this.createError(r.OBJECT_PROPERTIES_MINIMUM, {
            propertyCount: d.length,
            minimum: b.minProperties
        }, "", "/minProperties", null, a, b), this.handleError(c)) ? c : void 0 !== b.maxProperties && d.length > b.maxProperties && (c = this.createError(r.OBJECT_PROPERTIES_MAXIMUM, {
            propertyCount: d.length,
            maximum: b.maxProperties
        }, "", "/maxProperties", null, a, b), this.handleError(c)) ? c : null
    }, o.prototype.validateObjectRequiredProperties = function(a, b) {
        if (void 0 !== b.required)
            for (var c = 0; c < b.required.length; c++) {
                var d = b.required[c];
                if (void 0 === a[d]) {
                    var e = this.createError(r.OBJECT_REQUIRED, {
                        key: d
                    }, "", "/required/" + c, null, a, b);
                    if (this.handleError(e)) return e
                }
            }
        return null
    }, o.prototype.validateObjectProperties = function(a, b, c) {
        var d;
        for (var e in a) {
            var f = c + "/" + e.replace(/~/g, "~0").replace(/\//g, "~1"),
                g = !1;
            if (void 0 !== b.properties && void 0 !== b.properties[e] && (g = !0, d = this.validateAll(a[e], b.properties[e], [e], ["properties", e], f))) return d;
            if (void 0 !== b.patternProperties)
                for (var h in b.patternProperties) {
                    var i = new RegExp(h);
                    if (i.test(e) && (g = !0, d = this.validateAll(a[e], b.patternProperties[h], [e], ["patternProperties", h], f))) return d
                }
            if (g) this.trackUnknownProperties && (this.knownPropertyPaths[f] = !0, delete this.unknownPropertyPaths[f]);
            else if (void 0 !== b.additionalProperties) {
                if (this.trackUnknownProperties && (this.knownPropertyPaths[f] = !0, delete this.unknownPropertyPaths[f]), "boolean" == typeof b.additionalProperties) {
                    if (!b.additionalProperties && (d = this.createError(r.OBJECT_ADDITIONAL_PROPERTIES, {
                            key: e
                        }, "", "/additionalProperties", null, a, b).prefixWith(e, null), this.handleError(d))) return d
                } else if (d = this.validateAll(a[e], b.additionalProperties, [e], ["additionalProperties"], f)) return d
            } else this.trackUnknownProperties && !this.knownPropertyPaths[f] && (this.unknownPropertyPaths[f] = !0)
        }
        return null
    }, o.prototype.validateObjectDependencies = function(a, b, c) {
        var d;
        if (void 0 !== b.dependencies)
            for (var e in b.dependencies)
                if (void 0 !== a[e]) {
                    var f = b.dependencies[e];
                    if ("string" == typeof f) {
                        if (void 0 === a[f] && (d = this.createError(r.OBJECT_DEPENDENCY_KEY, {
                                key: e,
                                missing: f
                            }, "", "", null, a, b).prefixWith(null, e).prefixWith(null, "dependencies"), this.handleError(d))) return d
                    } else if (Array.isArray(f))
                        for (var g = 0; g < f.length; g++) {
                            var h = f[g];
                            if (void 0 === a[h] && (d = this.createError(r.OBJECT_DEPENDENCY_KEY, {
                                    key: e,
                                    missing: h
                                }, "", "/" + g, null, a, b).prefixWith(null, e).prefixWith(null, "dependencies"), this.handleError(d))) return d
                        } else if (d = this.validateAll(a, f, [], ["dependencies", e], c)) return d
                } return null
    }, o.prototype.validateCombinations = function(a, b, c) {
        return this.validateAllOf(a, b, c) || this.validateAnyOf(a, b, c) || this.validateOneOf(a, b, c) || this.validateNot(a, b, c) || null
    }, o.prototype.validateAllOf = function(a, b, c) {
        if (void 0 === b.allOf) return null;
        for (var d, e = 0; e < b.allOf.length; e++) {
            var f = b.allOf[e];
            if (d = this.validateAll(a, f, [], ["allOf", e], c)) return d
        }
        return null
    }, o.prototype.validateAnyOf = function(a, b, c) {
        if (void 0 === b.anyOf) return null;
        var d, e, f = [],
            g = this.errors.length;
        this.trackUnknownProperties && (d = this.unknownPropertyPaths, e = this.knownPropertyPaths);
        for (var h = !0, i = 0; i < b.anyOf.length; i++) {
            this.trackUnknownProperties && (this.unknownPropertyPaths = {}, this.knownPropertyPaths = {});
            var j = b.anyOf[i],
                k = this.errors.length,
                l = this.validateAll(a, j, [], ["anyOf", i], c);
            if (null === l && k === this.errors.length) {
                if (this.errors = this.errors.slice(0, g), this.trackUnknownProperties) {
                    for (var m in this.knownPropertyPaths) e[m] = !0, delete d[m];
                    for (var n in this.unknownPropertyPaths) e[n] || (d[n] = !0);
                    h = !1;
                    continue
                }
                return null
            }
            l && f.push(l.prefixWith(null, "" + i).prefixWith(null, "anyOf"))
        }
        return this.trackUnknownProperties && (this.unknownPropertyPaths = d, this.knownPropertyPaths = e), h ? (f = f.concat(this.errors.slice(g)), this.errors = this.errors.slice(0, g), this.createError(r.ANY_OF_MISSING, {}, "", "/anyOf", f, a, b)) : void 0
    }, o.prototype.validateOneOf = function(a, b, c) {
        if (void 0 === b.oneOf) return null;
        var d, e, f = null,
            g = [],
            h = this.errors.length;
        this.trackUnknownProperties && (d = this.unknownPropertyPaths, e = this.knownPropertyPaths);
        for (var i = 0; i < b.oneOf.length; i++) {
            this.trackUnknownProperties && (this.unknownPropertyPaths = {}, this.knownPropertyPaths = {});
            var j = b.oneOf[i],
                k = this.errors.length,
                l = this.validateAll(a, j, [], ["oneOf", i], c);
            if (null === l && k === this.errors.length) {
                if (null !== f) return this.errors = this.errors.slice(0, h), this.createError(r.ONE_OF_MULTIPLE, {
                    index1: f,
                    index2: i
                }, "", "/oneOf", null, a, b);
                if (f = i, this.trackUnknownProperties) {
                    for (var m in this.knownPropertyPaths) e[m] = !0, delete d[m];
                    for (var n in this.unknownPropertyPaths) e[n] || (d[n] = !0)
                }
            } else l && g.push(l)
        }
        return this.trackUnknownProperties && (this.unknownPropertyPaths = d, this.knownPropertyPaths = e), null === f ? (g = g.concat(this.errors.slice(h)), this.errors = this.errors.slice(0, h), this.createError(r.ONE_OF_MISSING, {}, "", "/oneOf", g, a, b)) : (this.errors = this.errors.slice(0, h), null)
    }, o.prototype.validateNot = function(a, b, c) {
        if (void 0 === b.not) return null;
        var d, e, f = this.errors.length;
        this.trackUnknownProperties && (d = this.unknownPropertyPaths, e = this.knownPropertyPaths, this.unknownPropertyPaths = {}, this.knownPropertyPaths = {});
        var g = this.validateAll(a, b.not, null, null, c),
            h = this.errors.slice(f);
        return this.errors = this.errors.slice(0, f), this.trackUnknownProperties && (this.unknownPropertyPaths = d, this.knownPropertyPaths = e), null === g && 0 === h.length ? this.createError(r.NOT_PASSED, {}, "", "/not", null, a, b) : null
    }, o.prototype.validateHypermedia = function(a, b, d) {
        if (!b.links) return null;
        for (var e, f = 0; f < b.links.length; f++) {
            var g = b.links[f];
            if ("describedby" === g.rel) {
                for (var h = new c(g.href), i = !0, j = 0; j < h.varNames.length; j++)
                    if (!(h.varNames[j] in a)) {
                        i = !1;
                        break
                    } if (i) {
                    var k = h.fillFromObject(a),
                        l = {
                            $ref: k
                        };
                    if (e = this.validateAll(a, l, [], ["links", f], d)) return e
                }
            }
        }
    };
    var r = {
            INVALID_TYPE: 0,
            ENUM_MISMATCH: 1,
            ANY_OF_MISSING: 10,
            ONE_OF_MISSING: 11,
            ONE_OF_MULTIPLE: 12,
            NOT_PASSED: 13,
            NUMBER_MULTIPLE_OF: 100,
            NUMBER_MINIMUM: 101,
            NUMBER_MINIMUM_EXCLUSIVE: 102,
            NUMBER_MAXIMUM: 103,
            NUMBER_MAXIMUM_EXCLUSIVE: 104,
            NUMBER_NOT_A_NUMBER: 105,
            STRING_LENGTH_SHORT: 200,
            STRING_LENGTH_LONG: 201,
            STRING_PATTERN: 202,
            OBJECT_PROPERTIES_MINIMUM: 300,
            OBJECT_PROPERTIES_MAXIMUM: 301,
            OBJECT_REQUIRED: 302,
            OBJECT_ADDITIONAL_PROPERTIES: 303,
            OBJECT_DEPENDENCY_KEY: 304,
            ARRAY_LENGTH_SHORT: 400,
            ARRAY_LENGTH_LONG: 401,
            ARRAY_UNIQUE: 402,
            ARRAY_ADDITIONAL_ITEMS: 403,
            FORMAT_CUSTOM: 500,
            KEYWORD_CUSTOM: 501,
            CIRCULAR_REFERENCE: 600,
            UNKNOWN_PROPERTY: 1e3
        },
        s = {};
    for (var t in r) s[r[t]] = t;
    var u = {
        INVALID_TYPE: "Invalid type: {type} (expected {expected})",
        ENUM_MISMATCH: "No enum match for: {value}",
        ANY_OF_MISSING: 'Data does not match any schemas from "anyOf"',
        ONE_OF_MISSING: 'Data does not match any schemas from "oneOf"',
        ONE_OF_MULTIPLE: 'Data is valid against more than one schema from "oneOf": indices {index1} and {index2}',
        NOT_PASSED: 'Data matches schema from "not"',
        NUMBER_MULTIPLE_OF: "Value {value} is not a multiple of {multipleOf}",
        NUMBER_MINIMUM: "Value {value} is less than minimum {minimum}",
        NUMBER_MINIMUM_EXCLUSIVE: "Value {value} is equal to exclusive minimum {minimum}",
        NUMBER_MAXIMUM: "Value {value} is greater than maximum {maximum}",
        NUMBER_MAXIMUM_EXCLUSIVE: "Value {value} is equal to exclusive maximum {maximum}",
        NUMBER_NOT_A_NUMBER: "Value {value} is not a valid number",
        STRING_LENGTH_SHORT: "String is too short ({length} chars), minimum {minimum}",
        STRING_LENGTH_LONG: "String is too long ({length} chars), maximum {maximum}",
        STRING_PATTERN: "String does not match pattern: {pattern}",
        OBJECT_PROPERTIES_MINIMUM: "Too few properties defined ({propertyCount}), minimum {minimum}",
        OBJECT_PROPERTIES_MAXIMUM: "Too many properties defined ({propertyCount}), maximum {maximum}",
        OBJECT_REQUIRED: "Missing required property: {key}",
        OBJECT_ADDITIONAL_PROPERTIES: "Additional properties not allowed",
        OBJECT_DEPENDENCY_KEY: "Dependency failed - key must exist: {missing} (due to key: {key})",
        ARRAY_LENGTH_SHORT: "Array is too short ({length}), minimum {minimum}",
        ARRAY_LENGTH_LONG: "Array is too long ({length}), maximum {maximum}",
        ARRAY_UNIQUE: "Array items are not unique (indices {match1} and {match2})",
        ARRAY_ADDITIONAL_ITEMS: "Additional items not allowed",
        FORMAT_CUSTOM: "Format validation failed ({message})",
        KEYWORD_CUSTOM: "Keyword failed: {key} ({message})",
        CIRCULAR_REFERENCE: "Circular $refs: {urls}",
        UNKNOWN_PROPERTY: "Unknown property (not in schema)"
    };
    j.prototype = Object.create(Error.prototype), j.prototype.constructor = j, j.prototype.name = "ValidationError", j.prototype.prefixWith = function(a, b) {
        if (null !== a && (a = a.replace(/~/g, "~0").replace(/\//g, "~1"), this.dataPath = "/" + a + this.dataPath), null !== b && (b = b.replace(/~/g, "~0").replace(/\//g, "~1"), this.schemaPath = "/" + b + this.schemaPath), null !== this.subErrors)
            for (var c = 0; c < this.subErrors.length; c++) this.subErrors[c].prefixWith(a, b);
        return this
    };
    var v = {},
        w = l();
    return w.addLanguage("en-gb", u), w.tv4 = w, w
});