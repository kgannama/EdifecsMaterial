   if(context.getVariable('request.content')!== null)
    {
        
        if(context.getVariable('webhookType').toUpperCase() !== "ASSETS")
               {
                   context.setVariable("EH_ErrorDescription", 'WebhookType is invalid');
                   throw 'WebhookType is invalid';
                        
                }
         if(context.getVariable('assetReportStatus').toUpperCase() !== "PRODUCT_READY")
                {
           if(context.getVariable('assetReportStatus').toUpperCase() !== "ERROR")
                {
                       context.setVariable("EH_ErrorDescription", 'WebhookCode is invalid');
                   throw 'WebhookCode is invalid';
                }
                }
           
           if (context.getVariable('assetReportId') !== null) 
           {
            if (!IsValidGuid(context.getVariable('assetReportId'))) {
                        context.setVariable("EH_ErrorDescription", 'assetReportId is invalid');
                        throw 'assetReportId is invalid';

                }
            }
         if (context.getVariable('assetReportError') !== null) 
         {
        if (!validateErrorTypes(context.getVariable('assetReportError')))
        {
             context.setVariable("EH_ErrorDescription", 'errorType is invalid');
              throw 'errorType is invalid';
        }
         }
          if(context.getVariable('errorCode') !== null)
            
              {
            if (!validatestringlength(context.getVariable('errorCode'), 0, 100))
                {
                     context.setVariable("EH_ErrorDescription", 'errorCode char limit exceeded');
                     throw 'errorCode char limit exceeded';
                }
           if (!ValidateErrorMessage(context.getVariable('errorCode')))
                {
                     context.setVariable("EH_ErrorDescription", 'errorCode should not contain special characters');
                     throw 'errorCode should not contain special characters';
                    
                }
              }
            if(context.getVariable('errorMessage') !== null)
            
              {
            if (!validatestringlength(context.getVariable('errorMessage'), 0, 300))
                {
                     context.setVariable("EH_ErrorDescription", 'errorMessage char limit exceeded');
                     throw 'errorMessage char limit exceeded';
                }
            if (!ValidateErrorMessage(context.getVariable('errorMessage')))
                {
                     context.setVariable("EH_ErrorDescription", 'errorMessage should not contain special characters');
                     throw 'errorMessage should not contain special characters';
                    
                }
              }
            if(context.getVariable('displayMessage') !== null)
            
              {
           if (!validatestringlength(context.getVariable('displayMessage'), 0, 100))
                {
                     context.setVariable("EH_ErrorDescription", 'displayMessage should be between 1 to 100 characters');
                     throw 'displayMessage should be between 1 to 100 characters';
                    
                }
           if (!ValidateErrorMessage(context.getVariable('displayMessage')))
                {
                     context.setVariable("EH_ErrorDescription", 'displayMessage should not contain special characters');
                     throw 'displayMessage should not contain special characters';
                    
                }
              }
          if (context.getVariable('requestId') !== null) 
           {
            if (!IsValidGuid(context.getVariable('requestId'))) {
                       context.setVariable("EH_ErrorDescription", 'Invalid Requestid');
                       throw 'Invalid Requestid';

                }
            }
       
        
        
        
    }