 if (context.getVariable('webhookType') === null ||
        context.getVariable('webhookType') === "" ||
        context.getVariable('assetReportStatus') === null ||
        context.getVariable('assetReportStatus') === "" ||
        context.getVariable('assetReportId') === null ||
        context.getVariable('assetReportId') === "" )
        {
        context.setVariable("EH_ErrorDescription",'Required fields missing');
        throw 'Required fields missing';
        }