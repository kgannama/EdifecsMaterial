﻿using Microsoft.XLANGs.BaseTypes;
using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTFCU.BT.EFMS.Utility
{
    public class OracleHelper
    {
        public static XLANGMessage ConstructDNABioCatchMessage(string taxID, string accountNbr)
        {
            return XLangMessageHelpers.CreateXLANGMessageFromString(GetInfoFromDNA(taxID, accountNbr), "Body");
        }

        public static XLANGMessage ConstructOLB_DNABioCatchMessage(string taxID)
        {
            return XLangMessageHelpers.CreateXLANGMessageFromString(GetOLBInfoFromDNA(taxID), "Body");
        }

        public static string GetInfoFromDNA(string taxID, string accountNbr)
        {
            if (string.IsNullOrEmpty(taxID) && string.IsNullOrEmpty(accountNbr))
            {
                return "<BioCatch/>";
            }
            if (!string.IsNullOrEmpty(taxID) && string.IsNullOrEmpty(accountNbr))
            {
                accountNbr = "''";
            }
            string result = string.Empty;
            try
            {
                string connStr = SSOClientHelper.Read("FTFCU.BT.EFMS", "DNAConnectionString");
                using (OracleConnection conn = new OracleConnection(connStr))
                {
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.CommandType = System.Data.CommandType.Text;
                        cmd.CommandText = "select PACK_BIOCATCH.GET_P2PDATA('" + taxID + "', " + accountNbr + ") as data from dual";
                        cmd.BindByName = true;

                        conn.Open();

                        result = cmd.ExecuteScalar().ToString();
                    }
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                result = "<BioCatch/>";
                Helper.LogInformation(ex.Message, "GetInfoFromDNA", "An error was encountered while reading data from DNA DB");
            }
            return result;
        }

        public static string GetOLBInfoFromDNA(string taxID)
        {
            if (string.IsNullOrEmpty(taxID))
            {
                return "<BioCatch/>";
            }
            string result = string.Empty;
            try
            {
                string connStr = SSOClientHelper.Read("FTFCU.BT.EFMS", "DNAConnectionString");
                using (OracleConnection conn = new OracleConnection(connStr))
                {
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.CommandText = "PACK_BIOCATCH_OLB.GET_OLBACTIVITY";

                        // Bind the input parameter
                        OracleParameter IN_TAXID = cmd.Parameters.Add("IN_TAXID", OracleDbType.Varchar2);
                        IN_TAXID.Direction = System.Data.ParameterDirection.Input;
                        IN_TAXID.Value = taxID;

                        // Bind the output paramter
                        OracleParameter OUT_XML = cmd.Parameters.Add("OUT_XML", OracleDbType.XmlType);
                        OUT_XML.Direction = System.Data.ParameterDirection.Output;

                        conn.Open();
                        cmd.ExecuteNonQuery();

                        result = ((Oracle.DataAccess.Types.OracleXmlType)(cmd.Parameters["OUT_XML"].Value)).Value;
                        result = "<BioCatch>" + result + "</BioCatch>";
                    }
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                result = "<BioCatch/>";
                Helper.LogInformation(ex.Message, "GetOLBInfoFromDNA", "An error was encountered while reading data from DNA DB");
            }
            return result;
        }
    }
}
