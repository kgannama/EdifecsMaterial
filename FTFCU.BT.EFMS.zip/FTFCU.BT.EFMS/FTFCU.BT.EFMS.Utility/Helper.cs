﻿using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace FTFCU.BT.EFMS.Utility
{
    public class Helper
    {
        protected const string EventLogName = "Application";


        public string NewGuid()
        {
            return Guid.NewGuid().ToString();
        }

        public static string GenerateTransactionKey()
        {
            return Guid.NewGuid().ToString();
        }

        public static string GetOrgNumber(string pin, string taxID)
        {
            var _out = String.Empty;
            var _conString = SSOClientHelper.Read("FTFCU.BT.EFMS", "DNAConnectionString");
            var _cnOra = new OracleConnection(_conString);
            try
            {

                OracleCommand _cmOra;

                _cmOra = _cnOra.CreateCommand();
                _cmOra.CommandType = CommandType.StoredProcedure;
                _cmOra.CommandText = "GET_ORG_PERSON_DETAILS";
                _cmOra.BindByName = true;
                _cmOra.Parameters.Add("PARAM_PIN", OracleDbType.Varchar2).Value = pin;
                _cmOra.Parameters.Add("PARAM_TAXID", OracleDbType.Varchar2).Value = taxID;
                _cmOra.Parameters.Add("RECORDSET", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                _cnOra.Open();

                object result = _cmOra.ExecuteNonQuery();
                var reader = _cmOra.ExecuteReader();
                while (reader.Read())
                {
                    _out = Convert.ToString(reader["OWNERORGNBR"]);
                    break;
                }
                reader.Close();
                _cnOra.Close();
                _cnOra.Dispose();
            }
            catch (Exception)
            {
                _cnOra.Close();
                _cnOra.Dispose();
                EventLog.WriteEntry("FTFCU.BT.EFMS - FeatureSpace RiskAssessment", "Exception Occured at GetOrgNumber method", EventLogEntryType.Error);
            }
            return _out;
        }

        public static void LogInformation(string DataToWrite, string appName, string msgName)
        {
            appName = appName.Replace("FTFCU.BT.EFMS - ", "");
            var sourceName = "FTFCU.BT.EFMS - " + appName;
            try
            {
                //if (SSOClientHelper.Read("FTFCU.BT.FirstConnect", "CXCLogging") == "true")
                //{
                if (!EventLog.SourceExists(sourceName))
                {
                    EventLog.CreateEventSource(sourceName, EventLogName);
                }

                if (!String.IsNullOrEmpty(DataToWrite) && DataToWrite.Length > 32000)
                {
                    var strXmlDoc = DataToWrite.Substring(0, 30000);
                    EventLog.WriteEntry(sourceName, msgName + ": \n\n" + strXmlDoc, EventLogEntryType.Information);
                }
                else
                    EventLog.WriteEntry(sourceName, msgName + ": \n\n" + DataToWrite, EventLogEntryType.Information);
                //}
            }
            catch (Exception)
            {
                EventLog.WriteEntry(sourceName, msgName, EventLogEntryType.Error);
            }
        }

        public static string LastUpdateSorting(string d1, string d2, string d3, string d4, string d5, string d6)
        {
            string result = "";
            try
            {
                var updateList = new List<string>();

                updateList.Add(d1);
                updateList.Add(d2);
                updateList.Add(d3);
                updateList.Add(d4);
                updateList.Add(d5);
                updateList.Add(d6);

                var sortedDates = updateList.OrderByDescending(x => x);

                foreach (string d in sortedDates)
                {
                    if (!String.IsNullOrEmpty(d))
                    {
                        result = d.ToString();
                        break;
                    }
                    break;
                }
            }
            catch (Exception)
            {
                EventLog.WriteEntry("FTFCU.BT.EFMS - DepositModule", "Exception Occured at LastUpdateSorting method", EventLogEntryType.Error);
            }
            return result;
        }

        public static StringBuilder GetMemberDataFromDNA(string taxID, string accountNumber)
        {

            string result = string.Empty;
            StringBuilder finalResult = new StringBuilder();
            try
            {
                string connStr = SSOClientHelper.Read("FTFCU.BT.EFMS", "DNAConnectionString");
                using (OracleConnection conn = new OracleConnection(connStr))
                {
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.CommandText = "PACK_ACTIMIZE_ENTITY.GET_ENTITY_ACCOUNT";

                        // Bind the input parameter
                        OracleParameter IN_TAXID = cmd.Parameters.Add("IN_TAXID", OracleDbType.Varchar2);
                        IN_TAXID.Direction = System.Data.ParameterDirection.Input;
                        IN_TAXID.Value = taxID;

                        OracleParameter IN_ACCTNBR = cmd.Parameters.Add("IN_ACCTNBR", OracleDbType.Varchar2);
                        IN_ACCTNBR.Direction = System.Data.ParameterDirection.Input;
                        IN_ACCTNBR.Value = accountNumber;


                        // Bind the output paramter
                        OracleParameter OUT_XML = cmd.Parameters.Add("OUT_XML", OracleDbType.XmlType);
                        OUT_XML.Direction = System.Data.ParameterDirection.Output;


                        conn.Open();
                        cmd.ExecuteNonQuery();

                        result = ((Oracle.DataAccess.Types.OracleXmlType)(cmd.Parameters["OUT_XML"].Value)).Value;
                        finalResult.Append("<ns0:DNAResponse xmlns:ns0='http://FTFCU.BT.RiskAssessment.Schemas.GetDNAData_Custom'>" + result + "</ns0:DNAResponse>");


                    }
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                finalResult.Append("<ns0:DNAResponse xmlns:ns0='http://FTFCU.BT.RiskAssessment.Schemas.GetDNAData_Custom'>" + result + "</ns0:DNAResponse>");
                Helper.LogInformation(ex.Message, "FeatureSpace RiskAssessment", "GetMemberDataFromDNA : An error was encountered while reading data from DNA DB");


            }
            return finalResult;
        }

        public static decimal CalculateWireAmount(string appName, string propertyName, string currencyCode, string amount)
        {
            decimal wireAmount = 0.00M;
            decimal transactionAmount = Convert.ToDecimal(amount);
            try
            {
                if (currencyCode == "USD")
                {
                    wireAmount = transactionAmount;
                }
                else
                {
                    string connectionString = FTFCU.BT.EFMS.Utility.SSOConfigHelper.ReadNonStatic(appName, propertyName);
                    string queryString = "Select Rate from [dbo].[ActimizeCurrency] where CountryCd = @pCountryCode";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand command = new SqlCommand(queryString, connection);
                        command.Parameters.AddWithValue("@pCountryCode", currencyCode);
                        connection.Open();
                        SqlDataReader reader = command.ExecuteReader();
                        try
                        {
                            decimal rate = 1.00M;
                            while (reader.Read())
                            {
                                rate = Convert.ToDecimal(reader["Rate"]);
                            }
                            wireAmount = Decimal.Round(transactionAmount / rate, 2);
                        }
                        finally
                        {
                            // Always call Close when done reading.
                            reader.Close();
                        }
                    }
                }
            }
            catch (Exception exp)
            {
                throw exp.InnerException;
            }
            return wireAmount;
        }
    }
}