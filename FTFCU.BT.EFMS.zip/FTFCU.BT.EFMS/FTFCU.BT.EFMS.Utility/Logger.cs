﻿using Microsoft.XLANGs.BaseTypes;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Security;
using System.Text;
using System.Xml;
using System.Xml.XPath;

namespace FTFCU.BT.EFMS.Utility
{
    public class Logger
    {
        protected const string EventLogName = "Application";
        public static HashSet<string> sFieldsRequest = new HashSet<string> { };

        public static List<string> XPathRequest()
        {
            List<string> sXPathRequest = new List<string>();


            return sXPathRequest;
        }

        private static string Mask(string inValue)
        {
            int length = inValue.Length;
            if (length <= 2)
                return inValue;

            char maskCharacter = 'X';
            int start = 2;
            int maskLength = length - 2;
            string mask = new string(maskCharacter, maskLength);
            string unMaskStart = inValue.Substring(0, start);
            return unMaskStart + mask;
        }

        public static void LogInfo(XLANGMessage msg, string appName, string msgName, HashSet<string> sFields)
        {
            try
            {
                using (var bodyPart = (Stream)msg[0].RetrieveAs(typeof(Stream)))
                {
                    var sb = new StringBuilder();
                    using (var xReader = XmlReader.Create(bodyPart))
                    {
                        XmlWriterSettings xwSetting = new XmlWriterSettings();
                        xwSetting.OmitXmlDeclaration = true;
                        using (XmlWriter xWriter = XmlWriter.Create(sb, xwSetting))
                        {
                            var currentFieldName = string.Empty;
                            while (xReader.Read())
                            {
                                switch (xReader.NodeType)
                                {
                                    case XmlNodeType.Element:
                                        currentFieldName = xReader.LocalName;
                                        if (xReader.Prefix == string.Empty)
                                            xWriter.WriteStartElement(currentFieldName);
                                        else
                                            xWriter.WriteStartElement(xReader.Prefix, currentFieldName, xReader.NamespaceURI);

                                        if (xReader.HasAttributes)
                                            xWriter.WriteAttributes(xReader, true);

                                        if (xReader.IsEmptyElement)
                                            xWriter.WriteEndElement();
                                        break;

                                    case XmlNodeType.EndElement:
                                        currentFieldName = string.Empty;
                                        xWriter.WriteEndElement();
                                        break;

                                    case XmlNodeType.Text:
                                        if (sFields.Contains(currentFieldName))
                                            xWriter.WriteString(Mask(xReader.Value));
                                        else
                                            xWriter.WriteString(xReader.Value);
                                        break;

                                    case XmlNodeType.Whitespace:
                                        xWriter.WriteWhitespace(xReader.Value);
                                        break;
                                        //Other cases
                                }
                                xWriter.Flush();
                            }
                        }
                    }
                    Log(sb.ToString(), msgName, appName, EventLogEntryType.Information);
                }
            }
            catch (Exception ex)
            {
                Log("Error in masking data." + System.Environment.NewLine + ex.Message, msgName, appName, EventLogEntryType.Error);
            }
            finally
            {
                msg.Dispose();
            }
        }

        public static void LogInfo(XLANGMessage msg, string appName, string msgName, List<string> xPaths)
        {
            try
            {
                XmlDocument xDoc = new XmlDocument();
                using (var bodyPart = (Stream)msg[0].RetrieveAs(typeof(Stream)))
                {
                    xDoc.Load(bodyPart);

                    XPathNavigator navigator = xDoc.CreateNavigator();

                    foreach (var xPath in xPaths)
                    {
                        foreach (XPathNavigator nav in navigator.Select(xPath))
                        {
                            string value = nav.Value;
                            nav.SetValue(Mask(value));
                        }
                    }
                }
                Log(xDoc.OuterXml, msgName, appName, EventLogEntryType.Information);

            }
            catch (Exception ex)
            {
                Log("Error in masking data." + System.Environment.NewLine + ex.Message, msgName, appName, EventLogEntryType.Error);
            }
            finally
            {
                msg.Dispose();
            }
        }

        public static void LogInfo(XLANGMessage msg, string appName, string msgName)
        {
            string log;
            try
            {
                using (var reader = new StreamReader(msg[0].RetrieveAs(typeof(Stream)) as Stream))
                {
                    log = reader.ReadToEnd();
                }
                Log(log, msgName, appName, EventLogEntryType.Information);
            }
            catch (Exception ex)
            {
                Log(ex.Message, msgName, appName, EventLogEntryType.Error);
            }
            finally
            {
                msg.Dispose();
            }
        }

        public static void LogInfo(string msg, string appName, string msgName)
        {
            Log(msg, msgName, appName, EventLogEntryType.Information);
        }

        public static void LogWarning(string msg, string appName, string msgName)
        {
            Log(msg, msgName, appName, EventLogEntryType.Warning);
        }

        public static void LogError(string msg, string appName, string msgName)
        {
            Log(SecurityElement.Escape(msg), msgName, appName, EventLogEntryType.Error);
        }

        public static void Log(string msg, string msgName, string appName, EventLogEntryType elet)
        {
            var sourceName = "FTFCU.BT.EFMS - " + appName;
            if (string.IsNullOrEmpty(appName))
                sourceName = "FTFCU.BT.EFMS";

            try
            {

                if (!EventLog.SourceExists(sourceName))
                {
                    EventLog.CreateEventSource(sourceName, EventLogName);
                }

                if (!String.IsNullOrEmpty(msg) && msg.Length > 32000)
                    EventLog.WriteEntry(sourceName, msgName + ":" + System.Environment.NewLine + msg.Substring(0, 30000), elet);
                else
                    EventLog.WriteEntry(sourceName, msgName + ":" + System.Environment.NewLine + msg, elet);

            }
            catch (Exception ex)
            {
                EventLog.WriteEntry(sourceName, msgName + ":" + System.Environment.NewLine + ex.Message, EventLogEntryType.Error);
            }
        }

        public static List<string> XPathFeatureSpaceRequest()
        {
            List<string> sXPathRequest = new List<string>();
            //CreateWire
            sXPathRequest.Add("/*[local-name()='RiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessmentReq']/*[local-name()='TaxID' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='RiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessmentReq']/*[local-name()='PIN' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='RiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessmentReq']/*[local-name()='TrnPayeeAccountData' and namespace-uri()='']/*[local-name()='PayeeName' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='RiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessmentReq']/*[local-name()='TrnPayeeAccountData' and namespace-uri()='']/*[local-name()='PayeeLastName' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='RiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessmentReq']/*[local-name()='MemberNum' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='RiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessmentReq']/*[local-name()='TrnPayeeAccountData' and namespace-uri()='']/*[local-name()='PayeeAcctNum' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='RiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessmentReq']/*[local-name()='TrnPayeeAccountData' and namespace-uri()='']/*[local-name()='TrnPayeeAddr1' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='RiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessmentReq']/*[local-name()='TrnPayeeAccountData' and namespace-uri()='']/*[local-name()='TrnPayeeAddr2' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='RiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessmentReq']/*[local-name()='TrnPayeeAccountData' and namespace-uri()='']/*[local-name()='TrnPayeeCity' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='RiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessmentReq']/*[local-name()='TrnPayeeAccountData' and namespace-uri()='']/*[local-name()='TrnPayeeCountryCd' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='RiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessmentReq']/*[local-name()='TrnPayeeAccountData' and namespace-uri()='']/*[local-name()='TrnPayeeState' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='RiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessmentReq']/*[local-name()='TrnPayeeAccountData' and namespace-uri()='']/*[local-name()='TrnPayeeZip' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='RiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessmentReq']/*[local-name()='TrnPayeeAccountData' and namespace-uri()='']/*[local-name()='TrnAccouNumber' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='RiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessmentReq']/*[local-name()='BaseTransaction' and namespace-uri()='']/*[local-name()='OLBUserId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='RiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessmentReq']/*[local-name()='BaseTransaction' and namespace-uri()='']/*[local-name()='FrmAcctNum' and namespace-uri()='']");

            sXPathRequest.Add("/*[local-name()='RiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessmentReq']/*[local-name()='BaseTransaction' and namespace-uri()='']/*[local-name()='TrnRefNum' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='RiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessmentReq']/*[local-name()='MonetaryTransaction' and namespace-uri()='']/*[local-name()='PayeeAcctId' and namespace-uri()='']");


            sXPathRequest.Add("/*[local-name()='RiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessmentReq']/*[local-name()='OnlineSession' and namespace-uri()='']/*[local-name()='LoginName' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='RiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessmentReq']/*[local-name()='BaseTransaction' and namespace-uri()='']/*[local-name()='TrnRefNum' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='RiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessmentReq']/*[local-name()='MonetaryTransaction' and namespace-uri()='']/*[local-name()='PayeeAcctId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='RiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessmentReq']/*[local-name()='TrnPayeeAccountData' and namespace-uri()='']/*[local-name()='PayeeRoutingNum' and namespace-uri()='']");


            //Feature Space

            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='accountAddress' and namespace-uri()='']/*[local-name()='addressLine1' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='accountAgentId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='accountEntityId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='toId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='fromId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='accountId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='accountName' and namespace-uri()='']/*[local-name()='fullName' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='counterpartyAddress' and namespace-uri()='']/*[local-name()='addressLine1' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='counterpartyAddress' and namespace-uri()='']/*[local-name()='addressLine2' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='counterpartyAddress' and namespace-uri()='']/*[local-name()='addressLine3' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='counterpartyAddress' and namespace-uri()='']/*[local-name()='country' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='counterpartyAddress' and namespace-uri()='']/*[local-name()='postalCode' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='customerId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='decorationId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='deviceId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='transactionId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='ultimateCounterpartyId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='ultimateCounterpartyName' and namespace-uri()='']/*[local-name()='fullName' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='extraAccountDetails' and namespace-uri()='']/*[local-name()='birthOrIncorporationDate' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='extraAccountDetails' and namespace-uri()='']/*[local-name()='email' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='extraAccountDetails' and namespace-uri()='']/*[local-name()='phone' and namespace-uri()='']");

            sXPathRequest.Add("/*[local-name()='Root' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionResponse']/*[local-name()='originatingEvent' and namespace-uri()='']/*[local-name()='accountAgentId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='Root' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionResponse']/*[local-name()='originatingEvent' and namespace-uri()='']/*[local-name()='accountEntityId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='Root' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionResponse']/*[local-name()='originatingEvent' and namespace-uri()='']/*[local-name()='accountId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='Root' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionResponse']/*[local-name()='originatingEvent' and namespace-uri()='']/*[local-name()='counterpartyId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='Root' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionResponse']/*[local-name()='originatingEvent' and namespace-uri()='']/*[local-name()='customerId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='Root' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionResponse']/*[local-name()='originatingEvent' and namespace-uri()='']/*[local-name()='fromId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='Root' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionResponse']/*[local-name()='originatingEvent' and namespace-uri()='']/*[local-name()='toId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='Root' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionResponse']/*[local-name()='originatingEvent' and namespace-uri()='']/*[local-name()='tenantId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='Root' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionResponse']/*[local-name()='originatingEvent' and namespace-uri()='']/*[local-name()='_metadata' and namespace-uri()='']/*[local-name()='searchable' and namespace-uri()='']/*[local-name()='customerId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='Root' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionResponse']/*[local-name()='originatingEvent' and namespace-uri()='']/*[local-name()='_metadata' and namespace-uri()='']/*[local-name()='searchable' and namespace-uri()='']/*[local-name()='accountAgentId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='Root' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionResponse']/*[local-name()='originatingEvent' and namespace-uri()='']/*[local-name()='_metadata' and namespace-uri()='']/*[local-name()='searchable' and namespace-uri()='']/*[local-name()='counterpartyId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='Root' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionResponse']/*[local-name()='originatingEvent' and namespace-uri()='']/*[local-name()='_metadata' and namespace-uri()='']/*[local-name()='searchable' and namespace-uri()='']/*[local-name()='accountId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='Root' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionResponse']/*[local-name()='originatingEvent' and namespace-uri()='']/*[local-name()='_metadata' and namespace-uri()='']/*[local-name()='searchable' and namespace-uri()='']/*[local-name()='counterpartyEntityId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='Root' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionResponse']/*[local-name()='originatingEvent' and namespace-uri()='']/*[local-name()='_metadata' and namespace-uri()='']/*[local-name()='searchable' and namespace-uri()='']/*[local-name()='accountEntityId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='Root' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionResponse']/*[local-name()='originatingEvent' and namespace-uri()='']/*[local-name()='_metadata' and namespace-uri()='']/*[local-name()='searchable' and namespace-uri()='']/*[local-name()='customerEntityId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='Root' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionResponse']/*[local-name()='originatingEvent' and namespace-uri()='']/*[local-name()='customerEntityId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='ultimateCounterpartyId' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='ultimateCounterpartyName' and namespace-uri()='']/*[local-name()='fullName' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='extraAccountDetails' and namespace-uri()='']/*[local-name()='birthOrIncorporationDate' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='extraAccountDetails' and namespace-uri()='']/*[local-name()='email' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='extraAccountDetails' and namespace-uri()='']/*[local-name()='phone' and namespace-uri()='']");

            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='counterpartyName' and namespace-uri()='']/*[local-name()='fullName' and namespace-uri()='']");

            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='initiatingPartyName' and namespace-uri()='']/*[local-name()='fullName' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='initiatingPartyName' and namespace-uri()='']/*[local-name()='givenName' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='initiatingPartyName' and namespace-uri()='']/*[local-name()='surname' and namespace-uri()='']");

            sXPathRequest.Add("/*[local-name()='ARICTransactionReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest']/*[local-name()='extraAccountDetails' and namespace-uri()='']/*[local-name()='mobilePhone' and namespace-uri()='']");

            //Check Deposit
            
            sXPathRequest.Add("/*[local-name()='TypedPollingResultSet0' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']/*[local-name()='PERSNBR' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']");
            sXPathRequest.Add(" /*[local-name()='TypedPollingResultSet0' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']/*[local-name()='ORGNBR' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']");
            sXPathRequest.Add("/*[local-name()='TypedPollingResultSet0' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']/*[local-name()='FIRSTNAME' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']");
            sXPathRequest.Add("/*[local-name()='TypedPollingResultSet0' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']/*[local-name()='LASTNAME' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']");
            sXPathRequest.Add("/*[local-name()='TypedPollingResultSet0' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']/*[local-name()='ORGNAME' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']");
            sXPathRequest.Add("/*[local-name()='TypedPollingResultSet0' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']/*[local-name()='BIRTHINCORPDATE' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']");
            sXPathRequest.Add("/*[local-name()='TypedPollingResultSet0' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']/*[local-name()='ADDRESSLINE1' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']");
            sXPathRequest.Add("/*[local-name()='TypedPollingResultSet0' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']/*[local-name()='CITY' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']");
            sXPathRequest.Add("/*[local-name()='TypedPollingResultSet0' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']/*[local-name()='STATE' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']");
            sXPathRequest.Add("/*[local-name()='TypedPollingResultSet0' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']/*[local-name()='ZIPPOSTCODE' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']");
            sXPathRequest.Add("/*[local-name()='TypedPollingResultSet0' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']/*[local-name()='EMAIL' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']");
            sXPathRequest.Add("/*[local-name()='TypedPollingResultSet0' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']/*[local-name()='BUSINESS' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']");
            sXPathRequest.Add("/*[local-name()='TypedPollingResultSet0' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']/*[local-name()='PERSONAL' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']");
            sXPathRequest.Add("/*[local-name()='TypedPollingResultSet0' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']/*[local-name()='MOBILEPHONE' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']");
            sXPathRequest.Add("/*[local-name()='TypedPollingResultSet0' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']/*[local-name()='BRANCH_KEY' and namespace-uri()='http://schemas.microsoft.com/Sql/2008/05/TypedPolling/EFMSDeposit']");


            // DNA Response

            sXPathRequest.Add("/*[local-name()='DNAResponse' and namespace-uri()='http://FTFCU.BT.RiskAssessment.Schemas.GetDNAData_Custom']/*[local-name()='EntityAccount' and namespace-uri()='']/*[local-name()='PersonNumber' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='DNAResponse' and namespace-uri()='http://FTFCU.BT.RiskAssessment.Schemas.GetDNAData_Custom']/*[local-name()='EntityAccount' and namespace-uri()='']/*[local-name()='OrgNumber' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='DNAResponse' and namespace-uri()='http://FTFCU.BT.RiskAssessment.Schemas.GetDNAData_Custom']/*[local-name()='EntityAccount' and namespace-uri()='']/*[local-name()='FirstName' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='DNAResponse' and namespace-uri()='http://FTFCU.BT.RiskAssessment.Schemas.GetDNAData_Custom']/*[local-name()='EntityAccount' and namespace-uri()='']/*[local-name()='LastName' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='DNAResponse' and namespace-uri()='http://FTFCU.BT.RiskAssessment.Schemas.GetDNAData_Custom']/*[local-name()='EntityAccount' and namespace-uri()='']/*[local-name()='OrgName' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='DNAResponse' and namespace-uri()='http://FTFCU.BT.RiskAssessment.Schemas.GetDNAData_Custom']/*[local-name()='EntityAccount' and namespace-uri()='']/*[local-name()='DateOfBirth' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='DNAResponse' and namespace-uri()='http://FTFCU.BT.RiskAssessment.Schemas.GetDNAData_Custom']/*[local-name()='EntityAccount' and namespace-uri()='']/*[local-name()='EmailAddress' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='DNAResponse' and namespace-uri()='http://FTFCU.BT.RiskAssessment.Schemas.GetDNAData_Custom']/*[local-name()='EntityAccount' and namespace-uri()='']/*[local-name()='CityName' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='DNAResponse' and namespace-uri()='http://FTFCU.BT.RiskAssessment.Schemas.GetDNAData_Custom']/*[local-name()='EntityAccount' and namespace-uri()='']/*[local-name()='ZipCode' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='DNAResponse' and namespace-uri()='http://FTFCU.BT.RiskAssessment.Schemas.GetDNAData_Custom']/*[local-name()='EntityAccount' and namespace-uri()='']/*[local-name()='CellNumber' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='DNAResponse' and namespace-uri()='http://FTFCU.BT.RiskAssessment.Schemas.GetDNAData_Custom']/*[local-name()='EntityAccount' and namespace-uri()='']/*[local-name()='CountryCode' and namespace-uri()='']");
            sXPathRequest.Add("/*[local-name()='DNAResponse' and namespace-uri()='http://FTFCU.BT.RiskAssessment.Schemas.GetDNAData_Custom']/*[local-name()='EntityAccount' and namespace-uri()='']/*[local-name()='StateCode' and namespace-uri()='']");

            return sXPathRequest;
        }

    }
}
