﻿using Microsoft.XLANGs.BaseTypes;
using System;
using Microsoft.BizTalk.XLANGs.BTXEngine;
using Microsoft.XLANGs.Core;
using System.IO;

namespace FTFCU.BT.EFMS.Utility
{
    [Serializable]
    internal sealed class CustomBTXMessage : BTXMessage
    {
        public CustomBTXMessage(string messageName, Context context)
            : base(messageName, context)
        {
            context.RefMessage(this);
        }
    }
    public class XLangMessageHelpers
    {
        public static XLANGMessage CreateXLANGMessageFromString(string message, string messagePartName)
        {
            var customBTXMessage = CreateMessagePart(message, messagePartName, null, 0);
            return customBTXMessage.GetMessageWrapperForUserCode();
        }

        private static CustomBTXMessage CreateMessagePart(string message, string messagePartName, CustomBTXMessage customBTXMessage, int index)
        {
            customBTXMessage = new CustomBTXMessage("Response", Service.RootService.XlangStore.OwningContext);
            MemoryStream stream = new MemoryStream();
            using (StreamWriter writer = new StreamWriter(stream))
            {
                writer.Write(message);
                writer.Flush();
                stream.Position = 0;
                stream.Seek(0, SeekOrigin.Begin);               
                customBTXMessage.AddPart(string.Empty, messagePartName);
                customBTXMessage[index].LoadFrom(stream);
            }
           
            return customBTXMessage;
        }

        public static string CreateStringFromXLANGMessage(XLANGMessage message, int index)
        {
            string toReturn;

            try
            {
                using (var reader = new StreamReader(message[index].RetrieveAs(typeof(Stream)) as Stream))
                {
                    toReturn = reader.ReadToEnd();
                }
            }
            finally
            {
                message.Dispose();
            }

            return toReturn;
        }

    }
}
