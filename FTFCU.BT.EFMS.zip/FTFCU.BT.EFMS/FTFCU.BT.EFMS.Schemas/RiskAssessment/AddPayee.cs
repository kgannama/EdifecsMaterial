namespace FTFCU.BT.EFMS.Schemas.RiskAssessment {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://FTFCU.BT.EFMS.Schemas.RiskAssessment.UpdateDetailsRiskAssessmentReq",@"UpdateDetailsRiskAssessmentReq")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "baseTransaction.transactionKey", XPath = @"/*[local-name()='UpdateDetailsRiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessment.UpdateDetailsRiskAssessmentReq']/*[local-name()='baseTransaction' and namespace-uri()='']/*[local-name()='transactionKey' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "channel", XPath = @"/*[local-name()='UpdateDetailsRiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessment.UpdateDetailsRiskAssessmentReq']/*[local-name()='channel' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "taxId", XPath = @"/*[local-name()='UpdateDetailsRiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessment.UpdateDetailsRiskAssessmentReq']/*[local-name()='taxId' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "activityName", XPath = @"/*[local-name()='UpdateDetailsRiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessment.UpdateDetailsRiskAssessmentReq']/*[local-name()='activityName' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.DateTime), "baseTransaction.tranNormalizedDtTime", XPath = @"/*[local-name()='UpdateDetailsRiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessment.UpdateDetailsRiskAssessmentReq']/*[local-name()='baseTransaction' and namespace-uri()='']/*[local-name()='tranNormalizedDtTime' and namespace-uri()='']", XsdType = @"dateTime")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "accountId", XPath = @"/*[local-name()='UpdateDetailsRiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessment.UpdateDetailsRiskAssessmentReq']/*[local-name()='accountId' and namespace-uri()='']", XsdType = @"string")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"UpdateDetailsRiskAssessmentReq"})]
    public sealed class UpdateDetailsRiskAssessmentReq : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://FTFCU.BT.EFMS.Schemas.RiskAssessment.UpdateDetailsRiskAssessmentReq"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" targetNamespace=""http://FTFCU.BT.EFMS.Schemas.RiskAssessment.UpdateDetailsRiskAssessmentReq"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""UpdateDetailsRiskAssessmentReq"">
    <xs:annotation>
      <xs:appinfo>
        <b:properties>
          <b:property distinguished=""true"" xpath=""/*[local-name()='UpdateDetailsRiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessment.UpdateDetailsRiskAssessmentReq']/*[local-name()='baseTransaction' and namespace-uri()='']/*[local-name()='transactionKey' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='UpdateDetailsRiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessment.UpdateDetailsRiskAssessmentReq']/*[local-name()='channel' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='UpdateDetailsRiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessment.UpdateDetailsRiskAssessmentReq']/*[local-name()='taxId' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='UpdateDetailsRiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessment.UpdateDetailsRiskAssessmentReq']/*[local-name()='activityName' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='UpdateDetailsRiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessment.UpdateDetailsRiskAssessmentReq']/*[local-name()='baseTransaction' and namespace-uri()='']/*[local-name()='tranNormalizedDtTime' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='UpdateDetailsRiskAssessmentReq' and namespace-uri()='http://FTFCU.BT.EFMS.Schemas.RiskAssessment.UpdateDetailsRiskAssessmentReq']/*[local-name()='accountId' and namespace-uri()='']"" />
        </b:properties>
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""accountId"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""action"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""activityType"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""activityName"" type=""xs:string"" />
        <xs:element name=""channel"" type=""xs:string"" />
        <xs:element name=""baseTransaction"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""sessionId"" type=""xs:string"" />
              <xs:element name=""oLBUserId"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""tranLocalDtTime"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""tranNormalizedDtTime"" type=""xs:dateTime"" />
              <xs:element name=""transactionKey"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""bioCatchCustomerSessionId"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""name"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""fiirstName"" type=""xs:string"" />
              <xs:element name=""lastName"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""memberNumber"" type=""xs:string"" />
        <xs:element name=""onlineSession"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""hdrUserAgent"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""iPAddress"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""loginName"" type=""xs:string"" />
              <xs:element name=""startDateTime"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""seconFactorAuthFlag"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""hTTPHeader"" type=""xs:string"" />
              <xs:element name=""webJourney"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""taxId"" type=""xs:string"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public UpdateDetailsRiskAssessmentReq() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "UpdateDetailsRiskAssessmentReq";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
