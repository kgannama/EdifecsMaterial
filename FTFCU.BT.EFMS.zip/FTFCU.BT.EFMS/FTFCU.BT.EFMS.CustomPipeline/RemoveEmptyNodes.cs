﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.BizTalk.Component.Interop;
using Microsoft.BizTalk.Message.Interop;
using System.Collections;
using System.IO;
using System.Xml.Linq;
using Microsoft.BizTalk.Streaming;
using System.Diagnostics;

namespace FTFCU.BT.EFMS.CustomPipeline
{
    [ComponentCategory(CategoryTypes.CATID_PipelineComponent)]
    [ComponentCategory(CategoryTypes.CATID_Any)]
    [System.Runtime.InteropServices.Guid("14842231-9948-A4E7-BC94-5689A47BA691")]
    public class RemoveEmptyNodes : IBaseComponent, IComponentUI,
                Microsoft.BizTalk.Component.Interop.IComponent, IPersistPropertyBag
    {

        
        public IntPtr Icon
        {
            get { return IntPtr.Zero; }
        }
        public IEnumerator Validate(object projectSystem)
        {
            if (projectSystem == null)
                throw new System.ArgumentNullException("No project system");
            IEnumerator enumerator = null;
            ArrayList strList = new ArrayList();
            try
            {
            }
            catch (Exception e)
            {
                strList.Add(e.Message);
                enumerator = strList.GetEnumerator();
            }
            return enumerator;
        }
        public void GetClassID(out Guid classID)
        {
            classID = new System.Guid("0C876BF1-77E3-9948-AC33-3034AB1C93FE");
        }
        public void InitNew()
        { }
        public void Load(IPropertyBag propertyBag, int errorLog)
        {
            //string val = (string)ReadPropertyBag(propertyBag, "RootNode");
            //if (val != null) rootNode = val;
        }
        private static object ReadPropertyBag(IPropertyBag propertyBag, string propName)
        {
            object val = null;
            try
            {
                propertyBag.Read(propName, out val, 0);
            }

            catch (System.ArgumentException)
            {
                return val;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
            return val;
        }
        public void Save(IPropertyBag propertyBag, bool clearDirty, bool saveAllProperties)
        {
            //object val = (object)rootNode;
            //WritePropertyBag(propertyBag, "RootNode", val);
        }
        private static void WritePropertyBag(IPropertyBag propertyBag, string propName, object val)
        {
            try
            {
                propertyBag.Write(propName, ref val);
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
        public IBaseMessage Execute(IPipelineContext pContext, IBaseMessage pInMsg)
        {
            StreamReader sReader = null;
                try
                {
                sReader = new StreamReader(pInMsg.BodyPart.GetOriginalDataStream());
                    XDocument xd = XDocument.Load(sReader);
                    VirtualStream vts = new VirtualStream();
                    xd.Descendants()
                      .Where(e => (e.Attributes().All(a => a.IsNamespaceDeclaration))
                                && string.IsNullOrWhiteSpace(e.Value))
                      .Remove();
                    xd.Save(vts);
                    vts.Position = 0;
                    pInMsg.BodyPart.Data = vts;

                    pContext.ResourceTracker.AddResource(vts);
                }
                catch (Exception ex)
                {
                EventLog.WriteEntry("FTFCU.BT.EFMS - BillPayProcess", "RemoveEmptyNodesException" + ":" + System.Environment.NewLine + ex.Message, EventLogEntryType.Error);
                throw;
                }
            finally
            {
                if (sReader != null)
                {
                    sReader.Close();
                }
            }


            return pInMsg;
        }
        public string Description
        {
            get { return "Remove Empty Nodes Pipeline Component"; }
        }
        public string Name
        {
            get { return "EFMSRemoveEmptyNodes"; }
        }
        public string Version
        {
            get { return "1.0"; }
        }


    }
}
