﻿using System;
using System.IO;
using System.Text;
using System.Xml;
using System.Drawing;
using System.Resources;
using System.Reflection;
using System.Diagnostics;
using System.Collections;
using System.ComponentModel;
using Microsoft.BizTalk.Message.Interop;
using Microsoft.BizTalk.Component.Interop;
using Microsoft.BizTalk.Streaming;

namespace FTFCU.BT.EFMS.CustomPipeline
{
    [ComponentCategory(CategoryTypes.CATID_PipelineComponent)]
    [ComponentCategory(CategoryTypes.CATID_Any)]
    [System.Runtime.InteropServices.Guid("655C6EC4-DED4-4C6E-A59A-74526E0101D5")]
    public class ChangeNSPipeline : IBaseComponent, IComponentUI,
                Microsoft.BizTalk.Component.Interop.IComponent, IPersistPropertyBag
    {
        private System.Resources.ResourceManager resourceManager = new System.Resources.ResourceManager("BizTalk.PipelineComponents.NamespaceMgmt.NamespaceMngt", Assembly.GetExecutingAssembly());

        private string _TargetNamespace;
        private string _CurrentNSURI;

        public string TargetNamespace
        {
            get
            {
                return _TargetNamespace;
            }
            set
            {
                _TargetNamespace = value;
            }
        }

        public string CurrentNSURI
        {
            get
            {
                return _CurrentNSURI;
            }
            set
            {
                _CurrentNSURI = value;
            }
        }

        #region IBaseComponent members
        /// <summary>
        /// Name of the component
        /// </summary>
        private const string _description = "Pipeline component used to Replace the namespace of a root node";
        private const string _name = "EFMS.ReplaceNamespace";
        private const string _version = "1.0.0.0";

        // Component description
        public string Description
        {
            get { return _description; }
        }
        // Component name
        public string Name
        {
            get { return _name; }
        }
        // Component version
        public string Version
        {
            get { return _version; }
        }
        #endregion

        #region IPersistPropertyBag members
        /// <summary>
        /// Gets class ID of component for usage from unmanaged code.
        /// </summary>
        /// <param name="classid">
        /// Class ID of the component
        /// </param>
        public void GetClassID(out System.Guid classid)
        {
            classid = new System.Guid("655C6EC4-DED4-4C6E-A59A-74526E0101D5");
        }

        /// <summary>
        /// not implemented
        /// </summary>
        public void InitNew()
        {
        }

        /// <summary>
        /// Loads configuration properties for the component
        /// </summary>
        /// <param name="pb">Configuration property bag</param>
        /// <param name="errlog">Error status</param>
        public virtual void Load(Microsoft.BizTalk.Component.Interop.IPropertyBag pb, int errlog)
        {
            object val = null;
            val = this.ReadPropertyBag(pb, "TargetNamespace");
            if ((val != null))
            {
                this._TargetNamespace = ((string)(val));
            }
            val = this.ReadPropertyBag(pb, "CurrentNSURI");
            if ((val != null))
            {
                this._CurrentNSURI = ((string)(val));
            }

        }

        /// <summary>
        /// Saves the current component configuration into the property bag
        /// </summary>
        /// <param name="pb">Configuration property bag</param>
        /// <param name="fClearDirty">not used</param>
        /// <param name="fSaveAllProperties">not used</param>
        public virtual void Save(Microsoft.BizTalk.Component.Interop.IPropertyBag pb, bool fClearDirty, bool fSaveAllProperties)
        {
            this.WritePropertyBag(pb, "TargetNamespace", this.TargetNamespace);
            this.WritePropertyBag(pb, "CurrentNSURI", this.CurrentNSURI);
        }

        #region utility functionality
        /// <summary>
        /// Reads property value from property bag
        /// </summary>
        /// <param name="pb">Property bag</param>
        /// <param name="propName">Name of property</param>
        /// <returns>Value of the property</returns>
        private object ReadPropertyBag(Microsoft.BizTalk.Component.Interop.IPropertyBag pb, string propName)
        {
            object val = null;
            try
            {
                pb.Read(propName, out val, 0);
            }
            catch (System.ArgumentException)
            {
                return val;
            }
            catch (System.Exception e)
            {
                throw new System.ApplicationException(e.Message);
            }
            return val;
        }

        /// <summary>
        /// Writes property values into a property bag.
        /// </summary>
        /// <param name="pb">Property bag.</param>
        /// <param name="propName">Name of property.</param>
        /// <param name="val">Value of property.</param>
        private void WritePropertyBag(Microsoft.BizTalk.Component.Interop.IPropertyBag pb, string propName, object val)
        {
            try
            {
                pb.Write(propName, ref val);
            }
            catch (System.Exception e)
            {
                throw new System.ApplicationException(e.Message);
            }
        }
        #endregion
        #endregion

        #region IComponentUI members
        /// <summary>
        /// Component icon to use in BizTalk Editor
        /// </summary>
        [Browsable(false)]
        public IntPtr Icon
        {
            get { return IntPtr.Zero; }
        }

        /// <summary>
        /// The Validate method is called by the BizTalk Editor during the build 
        /// of a BizTalk project.
        /// </summary>
        /// <param name="obj">An Object containing the configuration properties.</param>
        /// <returns>The IEnumerator enables the caller to enumerate through a collection of strings containing error messages. These error messages appear as compiler error messages. To report successful property validation, the method should return an empty enumerator.</returns>
        public System.Collections.IEnumerator Validate(object obj)
        {
            // example implementation:
            // ArrayList errorList = new ArrayList();
            // errorList.Add("This is a compiler error");
            // return errorList.GetEnumerator();
            return null;
        }
        #endregion

        #region IComponent members
        /// <summary>
        /// Implements IComponent.Execute method.
        /// </summary>
        /// <param name="pc">Pipeline context</param>
        /// <param name="inmsg">Input message</param>
        /// <returns>Original input message</returns>
        /// <remarks>
        /// IComponent.Execute method is used to initiate
        /// the processing of the message in this pipeline component.
        /// </remarks>
        public Microsoft.BizTalk.Message.Interop.IBaseMessage Execute(Microsoft.BizTalk.Component.Interop.IPipelineContext pc,
            Microsoft.BizTalk.Message.Interop.IBaseMessage inmsg)
        {
            try
            {
                CurrentNSURI = CurrentNSURI.Trim();
                TargetNamespace = TargetNamespace.Trim();
                if (this.CurrentNSURI != null && this.TargetNamespace != null)
                {
                    inmsg.BodyPart.Data = new XMLNamespaceMgnt(inmsg.BodyPart.GetOriginalDataStream())
                    {
                        NewNSURI = this.TargetNamespace,
                        CurrentNSURI = this.CurrentNSURI
                    };
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return inmsg;
        }
        #endregion

        #region override xmlTransformationMgt

        public class XMLNamespaceMgnt : XmlTranslatorStream
        {
            public string NewNSURI { get; set; }

            public string CurrentNSURI { get; set; }

            protected override void TranslateStartElement(string prefix, string localName, string nsURI)
            {
                if (CurrentNSURI == nsURI)
                {
                    base.TranslateStartElement(prefix, localName, NewNSURI);
                }
                else
                {
                    base.TranslateStartElement(prefix, localName, nsURI);
                }
            }

            protected override void TranslateAttribute()
            {
                if (this.m_reader.LocalName != "xmlns" && this.m_reader.Prefix != "xmlns")
                    base.TranslateAttribute();
            }

            public XMLNamespaceMgnt(Stream input)
                    : base(new XmlTextReader(input), Encoding.Default)
            {
            }
            protected override void TranslateXmlDeclaration(string target, string value)
            {
                this.m_writer.WriteProcessingInstruction(this.m_reader.Name, this.m_reader.Value);
            }
        }
        #endregion
    }




}
