namespace FTFCU.BT.EFMS.Maps {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"FTFCU.BT.EFMS.Schemas.RiskAssessment.EnrollPayee", typeof(global::FTFCU.BT.EFMS.Schemas.RiskAssessment.EnrollPayee))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"FTFCU.BT.EFMS.Schemas.RiskAssessment.UpdateFeatureSpaceFailedRequest_TypedProcedure_dbo+usp_UpdateFeatureSpaceFailedRequest", typeof(global::FTFCU.BT.EFMS.Schemas.RiskAssessment.UpdateFeatureSpaceFailedRequest_TypedProcedure_dbo.usp_UpdateFeatureSpaceFailedRequest))]
    public sealed class EnrollPayeeReq_To_UpdateFeatureSpaceFailedReq : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 userCSharp"" version=""1.0"" xmlns:ns0=""http://schemas.microsoft.com/Sql/2008/05/TypedProcedures/dbo"" xmlns:s0=""http://FTFCU.BT.EFMS.Schemas.RiskAssessment.EnrollPayeeRequest"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:EnrollPayeeRequest"" />
  </xsl:template>
  <xsl:template match=""/s0:EnrollPayeeRequest"">
    <xsl:variable name=""var:v1"" select=""userCSharp:StringConcat(&quot;insert&quot;)"" />
    <xsl:variable name=""var:v2"" select=""userCSharp:StringConcat(&quot;&quot;)"" />
    <xsl:variable name=""var:v3"" select=""userCSharp:StringConcat(&quot;false&quot;)"" />
    <ns0:usp_UpdateFeatureSpaceFailedRequest>
      <ns0:action>
        <xsl:value-of select=""$var:v1"" />
      </ns0:action>
      <ns0:transactionKey>
        <xsl:value-of select=""$var:v2"" />
      </ns0:transactionKey>
      <ns0:memberNumber>
        <xsl:value-of select=""PersonNumber/text()"" />
      </ns0:memberNumber>
      <xsl:if test=""Amount/NormalizedOrigAmt"">
        <ns0:normalizedOrigAmt>
          <xsl:value-of select=""Amount/NormalizedOrigAmt/text()"" />
        </ns0:normalizedOrigAmt>
      </xsl:if>
      <ns0:status>
        <xsl:value-of select=""$var:v3"" />
      </ns0:status>
      <ns0:exceptionType>
        <xsl:value-of select=""$var:v2"" />
      </ns0:exceptionType>
      <ns0:exceptionMsg>
        <xsl:value-of select=""$var:v2"" />
      </ns0:exceptionMsg>
      <xsl:element name=""ns0:payload"">
<xsl:text disable-output-escaping=""yes"">&lt;![CDATA[</xsl:text>
<xsl:copy-of select=""/"" />
<xsl:text disable-output-escaping=""yes"">]]&gt;</xsl:text>
</xsl:element>
      <ns0:responseMessage>
        <xsl:value-of select=""$var:v1"" />
      </ns0:responseMessage>
    </ns0:usp_UpdateFeatureSpaceFailedRequest>
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string StringConcat(string param0)
{
   return param0;
}



]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _xsltEngine = @"";
        
        private const int _useXSLTransform = 0;
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"FTFCU.BT.EFMS.Schemas.RiskAssessment.EnrollPayee";
        
        private const global::FTFCU.BT.EFMS.Schemas.RiskAssessment.EnrollPayee _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"FTFCU.BT.EFMS.Schemas.RiskAssessment.UpdateFeatureSpaceFailedRequest_TypedProcedure_dbo+usp_UpdateFeatureSpaceFailedRequest";
        
        private const global::FTFCU.BT.EFMS.Schemas.RiskAssessment.UpdateFeatureSpaceFailedRequest_TypedProcedure_dbo.usp_UpdateFeatureSpaceFailedRequest _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltEngine {
            get {
                return _xsltEngine;
            }
        }
        
        public override int UseXSLTransform {
            get {
                return _useXSLTransform;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"FTFCU.BT.EFMS.Schemas.RiskAssessment.EnrollPayee";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"FTFCU.BT.EFMS.Schemas.RiskAssessment.UpdateFeatureSpaceFailedRequest_TypedProcedure_dbo+usp_UpdateFeatureSpaceFailedRequest";
                return _TrgSchemas;
            }
        }
    }
}
