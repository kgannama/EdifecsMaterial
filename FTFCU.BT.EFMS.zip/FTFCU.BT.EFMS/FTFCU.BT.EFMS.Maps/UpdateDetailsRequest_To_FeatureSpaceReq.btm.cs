namespace FTFCU.BT.EFMS.Maps {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"FTFCU.BT.EFMS.Schemas.DNA.DNABioCatch", typeof(global::FTFCU.BT.EFMS.Schemas.DNA.DNABioCatch))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest", typeof(global::FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest))]
    public sealed class UpdateDetailsRequest_To_FeatureSpaceReq : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 s1 userCSharp"" version=""1.0"" xmlns:ns0=""http://FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest"" xmlns:s0=""http://FTFCU.BT.EFMS.Schemas.RiskAssessment.UpdateDetailsRiskAssessmentReq"" xmlns:s1=""http://schemas.microsoft.com/BizTalk/2003/aggschema"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s1:Root"" />
  </xsl:template>
  <xsl:template match=""/s1:Root"">
    <xsl:variable name=""var:vAgentId"" select=""userCSharp:StringConcat(&quot;321180379&quot;)"" />
    <xsl:variable name=""var:vAccountSchemCode"" select=""userCSharp:StringConcat(&quot;FT AccountNumber&quot;)"" />
    <xsl:variable name=""var:vAgentName"" select=""userCSharp:StringConcat(&quot;FTFCU&quot;)"" />
    <xsl:variable name=""var:vDirection"" select=""userCSharp:StringConcat(&quot;internal&quot;)"" />
    <xsl:variable name=""var:vCurrencyCode"" select=""userCSharp:StringConcat(&quot;USD&quot;)"" />
    <xsl:variable name=""var:vEventType"" select=""userCSharp:StringConcat(&quot;addPayee&quot;)"" />
    <xsl:variable name=""var:vInitiatingPartyIdSchemCode"" select=""userCSharp:StringConcat(&quot;AlkamiUserId&quot;)"" />
    <xsl:variable name=""var:vMsgStatus"" select=""userCSharp:StringConcat(&quot;New&quot;)"" />
    <xsl:variable name=""var:vMsgType"" select=""userCSharp:StringConcat(&quot;P2PInitiatePayment&quot;)"" />
    <xsl:variable name=""var:vSchemaVersion"" select=""userCSharp:StringConcat(&quot;1&quot;)"" />
    <xsl:variable name=""var:vTenantId"" select=""userCSharp:StringConcat(&quot;payments&quot;)"" />
    <xsl:variable name=""var:vToId"" select=""userCSharp:StringConcat(&quot;unknown&quot;)"" />
    <xsl:variable name=""var:vBCSID"" select=""InputMessagePart_0/s0:UpdateDetailsRiskAssessmentReq/baseTransaction/biocatchCustomerSessionID/text()"" />
    <ns0:ARICTransactionReq>
      <accountId>
        <xsl:value-of select=""InputMessagePart_0/s0:UpdateDetailsRiskAssessmentReq/accountId/text()"" />
      </accountId>
      <channel>
        <xsl:value-of select=""InputMessagePart_0/s0:UpdateDetailsRiskAssessmentReq/channel/text()"" />
      </channel>
      <xsl:for-each select=""InputMessagePart_0/s0:UpdateDetailsRiskAssessmentReq/name"">
        <xsl:if test=""firstName/text()!=''"">
          <counterpartyName>
            <xsl:if test=""firstName"">
              <givenName>
                <xsl:value-of select=""firstName/text()"" />
              </givenName>
            </xsl:if>
            <xsl:if test=""lastName"">
              <surname>
                <xsl:value-of select=""lastName/text()"" />
              </surname>
            </xsl:if>
          </counterpartyName>
        </xsl:if>
      </xsl:for-each>
      <customerId>
        <xsl:value-of select=""InputMessagePart_1/BioCatch/P2PDATA/@PERSNBR"" />
      </customerId>
      <decorationId>
        <xsl:value-of select=""$var:vTenantId"" />
      </decorationId>
      <direction>
        <xsl:value-of select=""$var:vDirection"" />
      </direction>
      <eventId>
        <xsl:value-of select=""InputMessagePart_0/s0:UpdateDetailsRiskAssessmentReq/baseTransaction/transactionKey/text()"" />
      </eventId>
      <eventTime>
        <xsl:value-of select=""InputMessagePart_0/s0:UpdateDetailsRiskAssessmentReq/baseTransaction/trnNormalizedDtTime/text()"" />
      </eventTime>
      <eventType>
        <xsl:value-of select=""$var:vEventType"" />
      </eventType>
      <fromId>
        <xsl:value-of select=""$var:vAgentId"" />
      </fromId>
      <initiatingPartyId>
        <xsl:value-of select=""InputMessagePart_0/s0:UpdateDetailsRiskAssessmentReq/baseTransaction/oLBUserId/text()"" />
      </initiatingPartyId>
      <mandateCreationOrUpdate>
        <xsl:value-of select=""InputMessagePart_0/s0:UpdateDetailsRiskAssessmentReq/action/text()"" />
      </mandateCreationOrUpdate>
      <msgStatus>
        <xsl:value-of select=""$var:vMsgStatus"" />
      </msgStatus>
      <schemaVersion>
        <xsl:value-of select=""$var:vSchemaVersion"" />
      </schemaVersion>
      <tenantId>
        <xsl:value-of select=""$var:vTenantId"" />
      </tenantId>
      <toId>
        <xsl:value-of select=""$var:vToId"" />
      </toId>
      <!--<transactionId>
        <xsl:value-of select=""InputMessagePart_0/s0:UpdateDetailsRiskAssessmentReq/baseTransaction/transactionKey/text()"" />
      </transactionId>-->
      <biocatchDetails>
        <customerSessionId>
          <xsl:value-of select=""$var:vBCSID"" />
        </customerSessionId>
      </biocatchDetails>
      <_metadata>
        <biocatchGetScoreExtraAttrs>
          <activityType>
            <xsl:value-of select=""InputMessagePart_0/s0:PaymentsRiskAssessmentReq/activityType/text()"" />
          </activityType>
          <activityName>
            <xsl:value-of select=""InputMessagePart_0/s0:PaymentsRiskAssessmentReq/activityName/text()"" />
          </activityName>
          <web_journey>
            <xsl:value-of select=""InputMessagePart_0/s0:PaymentsRiskAssessmentReq/onlineSession/webJourney/text()"" />
          </web_journey>
          <dateOfCreation>
            <xsl:value-of select=""InputMessagePart_1/BioCatch/OLBACTIVITY/dateOfCreation"" />
          </dateOfCreation>
          <P2PEnrollmentDate>
            <xsl:value-of select=""InputMessagePart_1/BioCatch/P2PDATA/@P2PDATE"" />
          </P2PEnrollmentDate>
        </biocatchGetScoreExtraAttrs>
      </_metadata>
    </ns0:ARICTransactionReq>
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp"">
    <![CDATA[
public string StringConcat(string param0)
{
   return param0;
}


public string StringConcat(string param0, string param1)
{
   return param0 + param1;
}
]]>
  </msxsl:script>
</xsl:stylesheet>";
        
        private const string _xsltEngine = @"";
        
        private const int _useXSLTransform = 0;
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"FTFCU.BT.EFMS.Schemas.DNA.DNABioCatch";
        
        private const global::FTFCU.BT.EFMS.Schemas.DNA.DNABioCatch _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest";
        
        private const global::FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltEngine {
            get {
                return _xsltEngine;
            }
        }
        
        public override int UseXSLTransform {
            get {
                return _useXSLTransform;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"FTFCU.BT.EFMS.Schemas.DNA.DNABioCatch";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"FTFCU.BT.EFMS.Schemas.ARIC.ARICTransactionRequest";
                return _TrgSchemas;
            }
        }
    }
}
