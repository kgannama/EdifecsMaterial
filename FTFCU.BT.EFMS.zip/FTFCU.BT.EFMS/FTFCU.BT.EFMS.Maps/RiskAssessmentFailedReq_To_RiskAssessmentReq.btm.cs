namespace FTFCU.BT.EFMS.Maps {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"FTFCU.BT.EFMS.Schemas.RiskAssessment.RiskAssessmentFailedReq", typeof(global::FTFCU.BT.EFMS.Schemas.RiskAssessment.RiskAssessmentFailedReq))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"FTFCU.BT.EFMS.Schemas.RiskAssessment.RiskAssessmentReq", typeof(global::FTFCU.BT.EFMS.Schemas.RiskAssessment.RiskAssessmentReq))]
    public sealed class RiskAssessmentFailedReq_To_RiskAssessmentReq : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0"" version=""1.0"" xmlns:s0=""http://FTFCU.BT.EFMS.Schemas.RiskAssessmentFailedReq"" xmlns:ns0=""http://FTFCU.BT.EFMS.Schemas.RiskAssessmentReq"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:RiskAssessmentFailedReq"" />
  </xsl:template>
  <xsl:template match=""/s0:RiskAssessmentFailedReq"">
    <xsl:call-template name=""Cdata"">
      <xsl:with-param name=""Payload"" select=""string(Payload/text())"" />
    </xsl:call-template>
  </xsl:template>
  <xsl:template name=""Cdata"">  
<xsl:param name=""Payload"" /> 
<xsl:value-of disable-output-escaping=""yes"" select=""$Payload"" /> 
</xsl:template>
</xsl:stylesheet>";
        
        private const string _xsltEngine = @"";
        
        private const int _useXSLTransform = 0;
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"FTFCU.BT.EFMS.Schemas.RiskAssessment.RiskAssessmentFailedReq";
        
        private const global::FTFCU.BT.EFMS.Schemas.RiskAssessment.RiskAssessmentFailedReq _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"FTFCU.BT.EFMS.Schemas.RiskAssessment.RiskAssessmentReq";
        
        private const global::FTFCU.BT.EFMS.Schemas.RiskAssessment.RiskAssessmentReq _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltEngine {
            get {
                return _xsltEngine;
            }
        }
        
        public override int UseXSLTransform {
            get {
                return _useXSLTransform;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"FTFCU.BT.EFMS.Schemas.RiskAssessment.RiskAssessmentFailedReq";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"FTFCU.BT.EFMS.Schemas.RiskAssessment.RiskAssessmentReq";
                return _TrgSchemas;
            }
        }
    }
}
