var token = context.getVariable("request.formparam.refresh_token");
//print(token.length);
if (token === null || token.length < 6 || token.length > 40){
    throw new Error("refresh_token form param is required and length must be greater than 5 and less than 40 chars");
}