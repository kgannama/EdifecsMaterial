var accountListPhone = context.getVariable("accountlist_phone");

if (accountListPhone.length < 10){
    accountListPhone = "";
}

context.setVariable("accountlist_phone", accountListPhone);
