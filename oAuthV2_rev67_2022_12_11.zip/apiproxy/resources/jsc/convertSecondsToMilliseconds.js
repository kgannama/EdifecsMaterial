     var expiresIn = context.getVariable('idp_expires_in');
 
    //remove ten seconds from the expires_in time to ensure the edge token expires prior to the IDP token.
    expiresIn -= 10;
 
    //convert expires time to milliseconds
    expiresIn *= 1000;
    
    //remove any decimal and set to string for oAuth policy
    context.setVariable('idp_expires_in', Math.trunc(expiresIn).toString());