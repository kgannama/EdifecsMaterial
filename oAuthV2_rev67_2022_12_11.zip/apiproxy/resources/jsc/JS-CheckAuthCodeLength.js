var code = context.getVariable("request.formparam.code");
//print(code.length);
if (code === null || code.length < 6 || code.length > 40){
    throw new Error("code form param is required and length must be greater than 5 and less than 40 chars");
}