  var oas={
  "swagger": "2.0",
  "info": {
    "description": "This is a Sample Specification document for enabling API to recieve Docusign Webhook Events",
    "version": "1.0.0",
    "title": "API Specification Document for enabling API to recieve Docusign Webhook Events",
    "contact": {
      "email": "Yeshwanth.Aendapally@firsttechfed.com"
    }
  },
  "host": "ftapinotification.firsttechfed.com",
  "basePath": "/v1/ACHOrgination",
  "tags": [
    {
      "name": "Docusign",
      "description": "All about the Docusign events webhook"
    }
  ],
  "schemes": [
    "https"
  ],
  "paths": {
    "/GetNotification": {
      "post": {
        "tags": [
          "Docusign"
        ],
        "summary": "Get Notification from Docusign",
        "description": "",
        "operationId": "GetNotification",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "parameters": [
          {
            "in": "body",
            "name": "body",
            "description": "Get Notification from Docusign",
            "required": true,
            "schema": {
              "$ref": "#/definitions/GetNotificationRequest"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/GetNotificationResponse"
            }
          },
          "422": {
            "description": "Required field validation failure. ",
            "schema": {
              "$ref": "#/definitions/RequiredFieldValidationResponse"
            }
          },
          "423": {
            "description": "Input Field Validation Failure.",
            "schema": {
              "$ref": "#/definitions/InputFieldValidationResponse"
            }
          },
          "429": {
            "description": "Exceeded quota limit. Partner can retry the request after a minute. API is configured for 10 request per minute",
            "schema": {
              "$ref": "#/definitions/QuotaLimitValidationResponse"
            }
          },
          "500": {
            "description": "System Exceptions. Partner can retry and if the issue still persist, should follow the First Tech Support process identified for the partner.",
            "schema": {
              "$ref": "#/definitions/Response500Error"
            }
          },
          "504": {
            "description": "Timeout. Partner can retry and if the issue still persist, should follow the First Tech Support process identified for the partner.",
            "schema": {
              "$ref": "#/definitions/ResponseValidationTimeout"
            }
          }
        }
      }
    }
  },
  "definitions": {
    "GetNotificationRequest": {
      "type": "object",
      "required": [
        "event",
        "uri"
      ],
      "properties": {
        "event": {
          "type": "string",
          "enum": [
            "envelope-delivered",
            "envelope-completed",
            "envelope-declined",
            "envelope-voided"
          ],
          "description": "type of event triger from docusign</br> enum check </br>"
        },
        "apiVersion": {
          "type": "string",
          "description": "version of API.</br> API would fail with required field failure if not supplied.</br> Can have only datetime value in UTC.</br>"
        },
        "uri": {
          "type": "string",
          "description": "docusign API URI to get details.</br>"
        },
        "retryCount": {
          "type": "number",
          "description": "Count of retries</br> integer check"
        },
        "configurationId": {
          "type": "number",
          "description": "Configuration ID.</br> Numeric Check"
        },
        "generatedDateTime": {
          "type": "string",
          "description": "date and time of event trigger</br> date time validation"
        },
        "data": {
          "type": "object",
          "required": [
            "accountId",
            "envelopeId"
          ],
          "description": "Object encapsulating metadata on the subject event.",
          "properties": {
            "accountId": {
              "type": "string",
              "description": "Id of the account</br> GUID validation"
            },
            "userId": {
              "type": "string",
              "description": "userid of the user</br> </br> GUID validation"
            },
            "envelopeId": {
              "type": "string",
              "description": "ID of the envelope</br>\nStandard GUID Format check. </br>"
            },
            "envelopeSummary": {
              "type": "object",
              "required": [
                "documentsUri",
                "recipientsUri",
                "attachmentsUri",
                "envelopeUri"
              ],
              "properties": {
                "status": {
                  "type": "string",
                  "description": "Status of the envelope</br> enum check </br>"
                },
                "documentsUri": {
                  "type": "string",
                  "description": "uri for documents</br> uri format check. </br>"
                },
                "recipientsUri": {
                  "type": "string",
                  "description": "uri for recipients</br> uri format check. </br>"
                },
                "attachmentsUri": {
                  "type": "string",
                  "description": "uri for attachments</br> uri format check. </br>"
                },
                "envelopeUri": {
                  "type": "string",
                  "description": "uri for envelope</br> uri format check. </br>"
                },
                "emailSubject": {
                  "type": "string",
                  "description": "uri for envelope</br> max 100 chars. </br>"
                },
                "envelopeId": {
                  "type": "string",
                  "description": "ID of the envelope</br> Standard GUID Format check. </br>"
                },
                "signingLocation": {
                  "type": "string",
                  "description": "location of document signing</br> max 25 chars. </br>"
                },
                "customFieldsUri": {
                  "type": "string",
                  "description": "uri for customFields</br> uri format check. </br>"
                },
                "notificationUri": {
                  "type": "string",
                  "description": "uri for notification</br> uri format check. </br>"
                },
                "enableWetSign": {
                  "type": "string",
                  "description": "option to enable/disable wetsign</br> boolean check. </br>"
                },
                "allowMarkup": {
                  "type": "string",
                  "description": "option to enable/disable markup</br> boolean check. </br>"
                },
                "allowReassign": {
                  "type": "string",
                  "description": "option to enable/disable Reassign</br> boolean check. </br>"
                },
                "createdDateTime": {
                  "type": "string",
                  "description": "date and time of envelope creation</br> datetime validation </br>"
                },
                "lastModifiedDateTime": {
                  "type": "string",
                  "description": "date and time of last update of envelope</br> datetime validation </br>"
                },
                "deliveredDateTime": {
                  "type": "string",
                  "description": "date and time of envelope delivery</br> datetime validation </br>"
                },
                "initialSentDateTime": {
                  "type": "string",
                  "description": "date and time of initial envelope sent</br> datetime validation </br>"
                },
                "sentDateTime": {
                  "type": "string",
                  "description": "date and time of  envelope sent</br> datetime validation </br>"
                },
                "completedDateTime": {
                  "type": "string",
                  "description": "date and time of  envelope completed</br> datetime validation </br>"
                },
                "statusChangedDateTime": {
                  "type": "string",
                  "description": "date and time of  envelope status change</br> datetime validation </br>"
                },
                "documentsCombinedUri": {
                  "type": "string",
                  "description": "uri for documents</br> uri format check. </br>"
                },
                "certificateUri": {
                  "type": "string",
                  "description": "uri for certificate</br> uri format check. </br>"
                },
                "templatesUri": {
                  "type": "string",
                  "description": "uri for templates</br> uri format check. </br>"
                },
                "expireEnabled": {
                  "type": "string",
                  "description": "option to enable/disable expire</br> boolean check. </br>"
                },
                "expireDateTime": {
                  "type": "string",
                  "description": "date and time of  envelope expiry</br> datetime validation </br>"
                },
                "expireAfter": {
                  "type": "string",
                  "description": "duration of the expiry option</br> Numeric validation </br>"
                },
                "sender": {
                  "type": "object",
                  "properties": {
                    "userName": {
                      "type": "string",
                      "description": "name of user</br> max 25 chars </br>"
                    },
                    "userId": {
                      "type": "string",
                      "description": "Id of user</br> GUID check </br>"
                    },
                    "accountId": {
                      "type": "string",
                      "description": "AccountId of user</br> GUID check </br>"
                    },
                    "email": {
                      "type": "string",
                      "description": "Email of user</br> Email Validation </br>"
                    }
                  }
                },
                "customFields": {
                  "type": "object",
                  "properties": {
                    "textCustomFields": {
                      "items": {
                        "$ref": "#/definitions/customFieldsrequest"
                      }
                    },
                    "listCustomFields": {
                      "type": "array",
                      "default": [],
                      "items": {
                        "type": "string"
                      }
                    }
                  }
                },
                "recipients": {
                  "type": "object",
                  "properties": {
                    "signers": {
                      "items": {
                        "$ref": "#/definitions/signersrequest"
                      }
                    },
                    "agents": {
                      "type": "array",
                      "default": [],
                      "items": {
                        "type": "string"
                      }
                    },
                    "editors": {
                      "type": "array",
                      "default": [],
                      "items": {
                        "type": "string"
                      }
                    },
                    "intermediaries": {
                      "type": "array",
                      "default": [],
                      "items": {
                        "type": "string"
                      }
                    },
                    "carbonCopies": {
                      "type": "array",
                      "default": [],
                      "items": {
                        "type": "string"
                      }
                    },
                    "certifiedDeliveries": {
                      "type": "array",
                      "default": [],
                      "items": {
                        "type": "string"
                      }
                    },
                    "inPersonSigners": {
                      "type": "array",
                      "default": [],
                      "items": {
                        "type": "string"
                      }
                    },
                    "seals": {
                      "type": "array",
                      "default": [],
                      "items": {
                        "type": "string"
                      }
                    },
                    "witnesses": {
                      "type": "array",
                      "default": [],
                      "items": {
                        "type": "string"
                      }
                    },
                    "notaries": {
                      "type": "array",
                      "default": [],
                      "items": {
                        "type": "string"
                      }
                    },
                    "recipientCount": {
                      "type": "string",
                      "description": "count of recipient</br>\nnumeric check </br>"
                    },
                    "currentRoutingOrder": {
                      "type": "string",
                      "description": "Current Routing Order</br>\nnumeric check </br>"
                    }
                  }
                },
                "purgeState": {
                  "type": "string",
                  "description": "purgeState</br> enum purged,unpurged </br>"
                },
                "envelopeIdStamping": {
                  "type": "string",
                  "description": "enable or diable envelopeIdStamping</br> boolean check </br>"
                },
                "is21CFRPart11": {
                  "type": "string",
                  "description": "enable or disable 21 CFRPart11</br> boolean check </br>"
                },
                "signerCanSignOnMobile": {
                  "type": "string",
                  "description": "enable or disable Mobile login</br> boolean check </br>"
                },
                "autoNavigation": {
                  "type": "string",
                  "description": "enable or disable autoNavigation</br> boolean check </br>"
                },
                "isSignatureProviderEnvelope": {
                  "type": "string",
                  "description": "checkbox to capture SignatureProviderEnvelope</br> boolean check </br>"
                },
                "hasFormDataChanged": {
                  "type": "string",
                  "description": "checkbox to capture form data change</br> boolean check </br>"
                },
                "allowComments": {
                  "type": "string",
                  "description": "enable or disable comments</br> boolean check </br>"
                },
                "hasComments": {
                  "type": "string",
                  "description": "check to see if there are Comments</br> boolean check </br>"
                },
                "allowViewHistory": {
                  "type": "string",
                  "description": "enable or disable ViewHistory</br> boolean check </br>"
                },
                "envelopeMetadata": {
                  "type": "object",
                  "properties": {
                    "allowAdvancedCorrect": {
                      "type": "string",
                      "description": "enable or disable advanced correct</br> boolean check </br>"
                    },
                    "enableSignWithNotary": {
                      "type": "string",
                      "description": "enable or disable notary signature</br> boolean check </br>"
                    },
                    "allowCorrect": {
                      "type": "string",
                      "description": "enable or disable correction</br> boolean check </br>"
                    }
                  }
                },
                "anySigner": {
                  "type":["string", "null"],
                  "default": null,
                  "description": ""
                },
                "envelopeLocation": {
                  "type": "string",
                  "description": "enable or disable correction</br> max 25 chars </br>"
                },
                "isDynamicEnvelope": {
                  "type": "string",
                  "description": "option to check for dynamic envelope</br> boolean check </br>"
                },
                "burnDefaultTabData": {
                  "type": "string",
                  "description": "option to enable/disable defaulttab data</br> boolean check </br>"
                }
              }
            }
          }
        }
      }
    },
    "signersrequest": {
      "type": "object",
      "properties": {
        "creationReason": {
          "type": "string",
          "description": "reason for envelope creation</br> max 50 chars </br>"
        },
        "canSignOffline": {
          "type": "string",
          "description": "option to enable/disable offline signing</br> boolean check </br>"
        },
        "isBulkRecipient": {
          "type": "string",
          "description": "check for bulk recipient</br> boolean check </br>"
        },
        "requireUploadSignature": {
          "type": "string",
          "description": "option to enable/disable signature upload</br> boolean check </br>"
        },
        "name": {
          "type": "string",
          "description": "name of signer</br> max 50 chars </br>"
        },
        "firstName": {
          "type": "string",
          "description": "firstname of signer</br> max 25 chars </br>"
        },
        "lastName": {
          "type": "string",
          "description": "lastname of signer</br> max 25 chars </br>"
        },
        "email": {
          "type": "string",
          "description": "name of signer</br> email validation </br>"
        },
        "recipientId": {
          "type": "string",
          "description": "ID of recipient</br> numeric check</br>"
        },
        "recipientIdGuid": {
          "type": "string",
          "description": "GUID of recipient</br> GUID validation</br>"
        },
        "requireIdLookup": {
          "type": "string",
          "description": "enable/disable ID lookup</br> boolean check</br>"
        },
        "userId": {
          "type": "string",
          "description": "Userid</br> Max 25 chars</br>"
        },
        "routingOrder": {
          "type": "string",
          "description": "ID of recipient</br> numeric check</br>"
        },
        "status": {
          "type": "string",
          "description": "status of envelope signing</br> Max 25 chars</br>"
        },
        "completedCount": {
          "type": "string",
          "description": "completedCount</br> numeric check</br>"
        },
        "signedDateTime": {
          "type": "string",
          "description": "date and time of envelope sign</br> datetime validation </br>"
        },
        "deliveredDateTime": {
          "type": "string",
          "description": "date and time of envelope delivery</br> datetime validation </br>"
        },
        "sentDateTime": {
          "type": "string",
          "description": "date and time of envelope sent</br> datetime validation </br>"
        },
        "deliveryMethod": {
          "type": "string",
          "description": "method of envelope delivery</br> max 25 chars </br>"
        },
        "recipientType": {
          "type": "string",
          "description": "type of recipient</br> max 10 chars </br>"
        }
      }
    },
    "customFieldsrequest": {
      "type": "object",
      "properties": {
        "fieldId": {
          "type": "string",
          "description": "Unique ID corresponding to the field</br> numeric check </br>"
        },
        "name": {
          "type": "string",
          "description": "field name </br> max 100 chars </br>"
        },
        "show": {
          "type": "string",
          "description": "display details or not</br> boolean validation </br>"
        },
        "required": {
          "type": "string",
          "description": "Is required</br> boolean check </br>"
        },
        "value": {
          "type": "string",
          "description": "value</br> max 100 chars, special character check </br>"
        }
      }
    },
    "GetNotificationResponse": {
      "type": "object",
      "properties": {
        "statusCode": {
          "type": "string",
          "description": "Http response code"
        },
        "statusMessage": {
          "type": "string",
          "description": "Status message"
        },
        "requestId": {
          "type": "string",
          "description": "Status message"
        }
      }
    },
    "Response500Error": {
      "type": "object",
      "properties": {
        "statusMessage": {
          "type": "string"
        },
        "requestId": {
          "type": "string",
          "description": "Unique identifier for each API call"
        },
        "statusCode": {
          "type": "string",
          "description": "System Exceptions. Partner can retry and if the issue still persist, should follow the First Tech Support process identified for the partner.",
          "enum": [
            "500"
          ]
        }
      }
    },
    "ResponseValidationTimeout": {
      "type": "object",
      "properties": {
        "statusCode": {
          "type": "string",
          "description": "Error Code",
          "enum": [
            "504"
          ]
        },
        "requestId": {
          "type": "string",
          "description": "Unique identifier for each API call"
        },
        "statusMessage": {
          "type": "string",
          "description": "Status message",
          "enum": [
            "Request Timed Out"
          ]
        }
      }
    },
    "QuotaLimitValidationResponse": {
      "type": "object",
      "properties": {
        "statusCode": {
          "type": "string",
          "description": "Error Code",
          "enum": [
            "429"
          ]
        },
        "statusMessage": {
          "type": "string",
          "description": "Status message",
          "enum": [
            "Too many requests"
          ]
        },
        "FaultName": {
          "type": "string",
          "enum": [
            "Quota Limit Exceeded"
          ]
        },
        "Error": {
          "type": "string",
          "enum": [
            "Rate limit quota violation. Quota limit exceeded"
          ]
        }
      }
    },
    "RequiredFieldValidationResponse": {
      "type": "object",
      "properties": {
        "statusCode": {
          "type": "integer",
          "enum": [
            422
          ],
          "description": "Required field validation failure"
        },
        "statusMessage": {
          "type": "string",
          "enum": [
            "Required Fields Missing"
          ]
        },
        "requestId": {
          "type": "string",
          "description": "Unique identifier for each API call"
        }
      }
    },
    "InputFieldValidationResponse": {
      "type": "object",
      "properties": {
        "statusCode": {
          "type": "string",
          "description": "Code",
          "enum": [
            "423"
          ]
        },
        "statusMessage": {
          "type": "string",
          "description": "Error Message",
          "enum": [
            "Validation Failure"
          ]
        },
        "requestId": {
          "type": "string",
          "description": "Unique identifier for each API call"
        }
      }
    }
  }
}