   if (context.getVariable('AcceptHeader') !== null) {
   if (context.getVariable('AcceptHeader') !== "application/json") {
       
            context.setVariable("EH_ErrorDescription", 'Invalid ContentType');
            throw 'Invalid Contenttype ';
		}
        }
if (context.getVariable('Verb') !== null) {
    if (context.getVariable('Verb') !== "POST") {
       
            context.setVariable("EH_ErrorDescription", 'Method not allowed');
            throw 'Method not allowed ';
		}
        }
