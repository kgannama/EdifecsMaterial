  var payload = JSON.parse(context.getVariable("request.content"));
payload.requestId = context.getVariable('requestId');

context.setVariable("request.content", JSON.stringify(payload));