 var thePayload = context.getVariable('request.content');
javascriptObject = JSON.parse(thePayload);

if (typeof javascriptObject.data.envelopeSummary.customFields.textCustomFields !== "undefined") {
var CounttextCustomFields = javascriptObject.data.envelopeSummary.customFields.textCustomFields.length;
    if (CounttextCustomFields > 4) {
        context.setVariable("EH_ErrorDescription", 'textCustomFields array out of bound');
        throw 'textCustomFields array out of bound';
    }
}
if (typeof javascriptObject.data.envelopeSummary.customFields.listCustomFields !== "undefined") {
var CountlistCustomFields = javascriptObject.data.envelopeSummary.customFields.listCustomFields.length;
    if (CountlistCustomFields > 4) {
        context.setVariable("EH_ErrorDescription", 'listCustomFields array out of bound');
        throw 'listCustomFields array out of bound';
    }
}

if (typeof javascriptObject.data.envelopeSummary.recipients.signers !== "undefined") {
var Countsigners = javascriptObject.data.envelopeSummary.recipients.signers.length;
    if (Countsigners > 4) {
        context.setVariable("EH_ErrorDescription", 'signers array out of bound');
        throw 'signers array out of bound';
    }
}

if (typeof javascriptObject.data.envelopeSummary.recipients.agents !== "undefined") {
var Countagents = javascriptObject.data.envelopeSummary.recipients.agents.length;
    if (Countagents > 4) {
        context.setVariable("EH_ErrorDescription", 'agents array out of bound');
        throw 'agents array out of bound';
    }
}

if (typeof javascriptObject.data.envelopeSummary.recipients.editors !== "undefined") {
var Counteditors = javascriptObject.data.envelopeSummary.recipients.editors.length;
    if (Counteditors > 4) {
        context.setVariable("EH_ErrorDescription", 'editors array out of bound');
        throw 'editors array out of bound';
    }
}

if (typeof javascriptObject.data.envelopeSummary.recipients.intermediaries !== "undefined") {
var Countintermediaries = javascriptObject.data.envelopeSummary.recipients.intermediaries.length;
    if (Countintermediaries > 4) {
        context.setVariable("EH_ErrorDescription", 'intermediaries array out of bound');
        throw 'intermediaries array out of bound';
    }
}

if (typeof javascriptObject.data.envelopeSummary.recipients.carbonCopies !== "undefined") {
var CountcarbonCopies = javascriptObject.data.envelopeSummary.recipients.carbonCopies.length;
    if (CountcarbonCopies > 4) {
        context.setVariable("EH_ErrorDescription", 'carbonCopies array out of bound');
        throw 'carbonCopies array out of bound';
    }
}

if (typeof javascriptObject.data.envelopeSummary.recipients.certifiedDeliveries !== "undefined") {
var CountcertifiedDeliveries = javascriptObject.data.envelopeSummary.recipients.certifiedDeliveries.length;
    if (CountcertifiedDeliveries > 4) {
        context.setVariable("EH_ErrorDescription", 'certifiedDeliveries array out of bound');
        throw 'certifiedDeliveries array out of bound';
    }
}

if (typeof javascriptObject.data.envelopeSummary.recipients.inPersonSigners !== "undefined") {
var CountinPersonSigners = javascriptObject.data.envelopeSummary.recipients.inPersonSigners.length;
    if (CountinPersonSigners > 4) {
        context.setVariable("EH_ErrorDescription", 'inPersonSigners array out of bound');
        throw 'inPersonSigners array out of bound';
    }
}

if (typeof javascriptObject.data.envelopeSummary.recipients.seals !== "undefined") {
var Countseals = javascriptObject.data.envelopeSummary.recipients.seals.length;
    if (Countseals > 4) {
        context.setVariable("EH_ErrorDescription", 'seals array out of bound');
        throw 'seals array out of bound';
    }
}

if (typeof javascriptObject.data.envelopeSummary.recipients.witnesses !== "undefined") {
var Countwitnesses = javascriptObject.data.envelopeSummary.recipients.witnesses.length;
    if (Countwitnesses > 4) {
        context.setVariable("EH_ErrorDescription", 'witnesses array out of bound');
        throw 'witnesses array out of bound';
    }
}

if (typeof javascriptObject.data.envelopeSummary.recipients.notaries !== "undefined") {
var Countnotaries = javascriptObject.data.envelopeSummary.recipients.notaries.length;
    if (Countnotaries > 4) {
        context.setVariable("EH_ErrorDescription", 'notaries array out of bound');
        throw 'notaries array out of bound';
    }
}

