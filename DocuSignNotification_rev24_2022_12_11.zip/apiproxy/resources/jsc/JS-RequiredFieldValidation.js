 
    if (context.getVariable('requestId') === null ||
        context.getVariable('requestId') === "" ||
        context.getVariable('event') === null ||
        context.getVariable('event') === "" ||
        context.getVariable('uri') === null ||
        context.getVariable('uri') === "" ||
        context.getVariable('accountId') === "" ||
        context.getVariable('accountId') === null ||
        context.getVariable('envelopeId') === "" ||
        context.getVariable('envelopeId') === null ||
        context.getVariable('documentsUri') === "" ||
        context.getVariable('documentsUri') === null ||
        context.getVariable('recipientsUri') === "" ||
        context.getVariable('recipientsUri') === null ||
        context.getVariable('attachmentsUri') === "" ||
        context.getVariable('attachmentsUri') === null  ||
        context.getVariable('envelopeUri') === "" ||
        context.getVariable('envelopeUri') === null)
        {
        context.setVariable("EH_ErrorDescription",'Required fields missing');
        throw 'Required fields missing';
        }
        