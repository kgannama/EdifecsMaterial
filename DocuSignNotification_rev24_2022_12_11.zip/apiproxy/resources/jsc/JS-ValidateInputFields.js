var thePayload = context.getVariable('request.content');
javascriptObject = JSON.parse(thePayload);


var RequestId = context.getVariable('requestId');

if (context.getVariable('requestId') !== null) {
    if (!IsValidGuid(context.getVariable('requestId'))) {
    context.setVariable("EH_ErrorDescription", 'Invalid Request ID');
    throw 'Invalid Request ID';
    }
}


if (context.getVariable('event') !== null) {
    if (context.getVariable('event').toUpperCase() !== "ENVELOPE-COMPLETED") 
    {
        if (context.getVariable('event').toUpperCase() !== "ENVELOPE-DELIVERED")
        {
            if (context.getVariable('event') !== "ENVELOPE-VOIDED")
            {
                if (context.getVariable('event').toUpperCase() !== "ENVELOPE-DECLINED")
                    {
                        if (context.getVariable('event').toUpperCase() !== "ENVELOPE-SIGNED")
                            {
                            context.setVariable("EH_ErrorDescription", 'Invalid event');
                            throw 'Invalid event';
                            }
                    }
            }
        }
    }
}

if (context.getVariable('apiVersion') !== null)
{
     if (!ValidateAPIversion(context.getVariable('apiVersion'))) {

            context.setVariable("EH_ErrorDescription", 'apiVersion is not valid ');
            throw 'apiVersion is not valid ';
        }
}


if (context.getVariable('uri') !== null)
{
     if (!ValidateDocuSignURI(context.getVariable('uri'))) {

            context.setVariable("EH_ErrorDescription", 'uri is not valid ');
            throw 'uri is not valid ';
        }
        
     if (!validatestringlength(context.getVariable('uri'), 0, 250)) {
        context.setVariable("EH_ErrorDescription", 'uri should be between 1 and 250 characters');
        throw 'uri should be between 1 and 250 characters';
    }
}

if (context.getVariable('retryCount') !== null)
{
     if (validateNumericData(context.getVariable('retryCount'))) {

            context.setVariable("EH_ErrorDescription", 'Invalid data type for retryCount');
            throw 'Invalid data type for retryCount';
        }
        
     if (!ValidateNumbers(context.getVariable('retryCount'))) {
         
        context.setVariable("EH_ErrorDescription", 'retryCount is not valid');
        throw 'retryCount is not valid';
    }
}

if (context.getVariable('configurationId') !== null)
{
     if (validateNumericData(context.getVariable('configurationId'))) {
         
            context.setVariable("EH_ErrorDescription", 'Invalid data type for configurationId');
            throw 'Invalid data type for configurationId';
        }
        
     if (!ValidateNumbers(context.getVariable('configurationId'))) {
         
        context.setVariable("EH_ErrorDescription", 'Invalid configurationId');
        throw 'Invalid configurationId';
    }
}

if (context.getVariable('generatedDateTime') !== null)
{
     if (!ValidateDateTimeWithOffset(context.getVariable('generatedDateTime'))) {
         
        context.setVariable("EH_ErrorDescription", 'Invalid generatedDateTime');
        throw 'Invalid generatedDateTime';
    }
}
    
if (context.getVariable('accountId') !== null) 
{
    if (!IsValidGuid(context.getVariable('accountId'))) {
        
    context.setVariable("EH_ErrorDescription", 'Invalid accountId');
    throw 'Invalid accountId';
    }
}

if (context.getVariable('userId') !== null)
{
    if (!IsValidGuid(context.getVariable('userId'))) {
        
    context.setVariable("EH_ErrorDescription", 'Invalid userId');
    throw 'Invalid userId';
    }
}

if (context.getVariable('envelopeId') !== null) 
{
    if (!IsValidGuid(context.getVariable('envelopeId'))) {
        
    context.setVariable("EH_ErrorDescription", 'Invalid envelopeId');
    throw 'Invalid envelopeId';
    }
}

if (context.getVariable('status') !== null) {
    if (!isValidNameList(context.getVariable('status'))) {

        context.setVariable("EH_ErrorDescription", 'status should not contain special characters');
        throw 'status should not contain special characters';
    }
    if (!validatestringlength(context.getVariable('status'), 0, 20)) {
        context.setVariable("EH_ErrorDescription", 'status should be between 1 and 20 characters');
        throw 'status should be between 1 and 20 characters';
    }
}

if (context.getVariable('documentsUri') !== null)
{
     if (!ValidateDocuSignURI(context.getVariable('documentsUri'))) {

            context.setVariable("EH_ErrorDescription", 'documentsUri is not valid ');
            throw 'documentsUri is not valid ';
        }
        
     if (!validatestringlength(context.getVariable('documentsUri'), 0, 250)) {
        context.setVariable("EH_ErrorDescription", 'documentsUri should be between 1 and 250 characters');
        throw 'documentsUri should be between 1 and 250 characters';
    }
}

if (context.getVariable('recipientsUri') !== null)
{
     if (!ValidateDocuSignURI(context.getVariable('recipientsUri'))) {

            context.setVariable("EH_ErrorDescription", 'recipientsUri is not valid ');
            throw 'recipientsUri is not valid ';
        }
        
     if (!validatestringlength(context.getVariable('recipientsUri'), 0, 250)) {
        context.setVariable("EH_ErrorDescription", 'recipientsUri should be between 1 and 250 characters');
        throw 'recipientsUri should be between 1 and 250 characters';
    }
}

if (context.getVariable('attachmentsUri') !== null)
{
     if (!ValidateDocuSignURI(context.getVariable('attachmentsUri'))) {

            context.setVariable("EH_ErrorDescription", 'attachmentsUri is not valid ');
            throw 'attachmentsUri is not valid ';
        }
        
     if (!validatestringlength(context.getVariable('attachmentsUri'), 0, 250)) {
         
        context.setVariable("EH_ErrorDescription", 'attachmentsUri should be between 1 and 250 characters');
        throw 'attachmentsUri should be between 1 and 250 characters';
    }
}

if (context.getVariable('envelopeUri') !== null)
{
     if (!ValidateDocuSignURI(context.getVariable('envelopeUri'))) {

            context.setVariable("EH_ErrorDescription", 'envelopeUri is not valid ');
            throw 'envelopeUri is not valid ';
        }
        
     if (!validatestringlength(context.getVariable('envelopeUri'), 0, 250)) {
         
        context.setVariable("EH_ErrorDescription", 'envelopeUri should be between 1 and 250 characters');
        throw 'envelopeUri should be between 1 and 250 characters';
    }
}

if (context.getVariable('emailSubject') !== null)
{
     if (!validatestringlength(context.getVariable('emailSubject'), 0, 100)) {
         
        context.setVariable("EH_ErrorDescription", 'emailSubject should be between 1 and 100 characters');
        throw 'emailSubject should be between 1 and 100 characters';
    }
    if (!isValidNameList(context.getVariable('emailSubject'))) {

        context.setVariable("EH_ErrorDescription", 'emailSubject should not contain special characters');
        throw 'emailSubject should not contain special characters';
    }
}

if (context.getVariable('SummaryenvelopeId') !== null) 
{
    if (!IsValidGuid(context.getVariable('SummaryenvelopeId'))) {
        
    context.setVariable("EH_ErrorDescription", 'Invalid envelopeSummary-envelopeId');
    throw 'Invalid envelopeSummary-envelopeId';
    }
}

if (context.getVariable('signingLocation') !== null)
{
     if (!validatestringlength(context.getVariable('signingLocation'), 0, 100)) {
         
        context.setVariable("EH_ErrorDescription", 'signingLocation should be between 1 and 100 characters');
        throw 'signingLocation should be between 1 and 100 characters';
    }
    if (!isValidNameList(context.getVariable('signingLocation'))) {

        context.setVariable("EH_ErrorDescription", 'signingLocation should not contain special characters');
        throw 'signingLocation should not contain special characters';
    }
}

if (context.getVariable('customFieldsUri') !== null)
{
     if (!ValidateDocuSignURI(context.getVariable('customFieldsUri'))) {

            context.setVariable("EH_ErrorDescription", 'customFieldsUri is not valid ');
            throw 'customFieldsUri is not valid ';
        }
        
     if (!validatestringlength(context.getVariable('customFieldsUri'), 0, 250)) {
         
        context.setVariable("EH_ErrorDescription", 'customFieldsUri should be between 1 and 250 characters');
        throw 'customFieldsUri should be between 1 and 250 characters';
    }
}

if (context.getVariable('notificationUri') !== null)
{
     if (!ValidateDocuSignURI(context.getVariable('notificationUri'))) {

            context.setVariable("EH_ErrorDescription", 'notificationUri is not valid ');
            throw 'notificationUri is not valid ';
        }
        
     if (!validatestringlength(context.getVariable('notificationUri'), 0, 250)) {
         
        context.setVariable("EH_ErrorDescription", 'notificationUri should be between 1 and 250 characters');
        throw 'notificationUri should be between 1 and 250 characters';
    }
}

if (context.getVariable('enableWetSign') !== null) {
    if (context.getVariable('enableWetSign').toUpperCase() !== "TRUE") 
    {
        if (context.getVariable('enableWetSign').toUpperCase() !== "FALSE")
        {
            context.setVariable("EH_ErrorDescription", 'Invalid enableWetSign');
            throw 'Invalid enableWetSign';
        }
    }
}

if (context.getVariable('allowMarkup') !== null) {
    if (context.getVariable('allowMarkup').toUpperCase() !== "TRUE") 
    {
        if (context.getVariable('allowMarkup').toUpperCase() !== "FALSE")
        {
            context.setVariable("EH_ErrorDescription", 'Invalid allowMarkup');
            throw 'Invalid allowMarkup';
        }
    }
}

if (context.getVariable('allowReassign') !== null) {
    if (context.getVariable('allowReassign').toUpperCase() !== "TRUE") 
    {
        if (context.getVariable('allowReassign').toUpperCase() !== "FALSE")
        {
            context.setVariable("EH_ErrorDescription", 'Invalid allowReassign');
            throw 'Invalid allowReassign';
        }
    }
}
 
if (context.getVariable('createdDateTime') !== null)
{
     if (!ValidateDateTimeWithOffset(context.getVariable('createdDateTime'))) {
         
        context.setVariable("EH_ErrorDescription", 'Invalid createdDateTime');
        throw 'Invalid createdDateTime';
    }
}

if (context.getVariable('lastModifiedDateTime') !== null)
{
     if (!ValidateDateTimeWithOffset(context.getVariable('lastModifiedDateTime'))) {
         
        context.setVariable("EH_ErrorDescription", 'Invalid lastModifiedDateTime');
        throw 'Invalid lastModifiedDateTime';
    }
}

if (context.getVariable('deliveredDateTime') !== null)
{
     if (!ValidateDateTimeWithOffset(context.getVariable('deliveredDateTime'))) {
         
        context.setVariable("EH_ErrorDescription", 'Invalid deliveredDateTime');
        throw 'Invalid deliveredDateTime';
    }
}

if (context.getVariable('initialSentDateTime') !== null)
{
     if (!ValidateDateTimeWithOffset(context.getVariable('initialSentDateTime'))) {
         
        context.setVariable("EH_ErrorDescription", 'Invalid initialSentDateTime');
        throw 'Invalid initialSentDateTime';
    }
}

if (context.getVariable('sentDateTime') !== null)
{
     if (!ValidateDateTimeWithOffset(context.getVariable('sentDateTime'))) {
         
        context.setVariable("EH_ErrorDescription", 'Invalid sentDateTime');
        throw 'Invalid sentDateTime';
    }
}

if (context.getVariable('completedDateTime') !== null)
{
     if (!ValidateDateTimeWithOffset(context.getVariable('completedDateTime'))) {
         
        context.setVariable("EH_ErrorDescription", 'Invalid completedDateTime');
        throw 'Invalid completedDateTime';
    }
}

if (context.getVariable('statusChangedDateTime') !== null)
{
     if (!ValidateDateTimeWithOffset(context.getVariable('statusChangedDateTime'))) {
         
        context.setVariable("EH_ErrorDescription", 'Invalid statusChangedDateTime');
        throw 'Invalid statusChangedDateTime';
    }
}
 
 if (context.getVariable('documentsCombinedUri') !== null)
{
     if (!ValidateDocuSignURI(context.getVariable('documentsCombinedUri'))) {

            context.setVariable("EH_ErrorDescription", 'documentsCombinedUri is not valid ');
            throw 'documentsCombinedUri is not valid ';
        }
        
     if (!validatestringlength(context.getVariable('documentsCombinedUri'), 0, 250)) {
         
        context.setVariable("EH_ErrorDescription", 'documentsCombinedUri should be between 1 and 250 characters');
        throw 'documentsCombinedUri should be between 1 and 250 characters';
    }
}   

 if (context.getVariable('certificateUri') !== null)
{
     if (!ValidateDocuSignURI(context.getVariable('certificateUri'))) {

            context.setVariable("EH_ErrorDescription", 'certificateUri is not valid ');
            throw 'certificateUri is not valid ';
        }
        
     if (!validatestringlength(context.getVariable('certificateUri'), 0, 250)) {
         
        context.setVariable("EH_ErrorDescription", 'certificateUri should be between 1 and 250 characters');
        throw 'certificateUri should be between 1 and 250 characters';
    }
} 

 if (context.getVariable('templatesUri') !== null)
{
     if (!ValidateDocuSignURI(context.getVariable('templatesUri'))) {

            context.setVariable("EH_ErrorDescription", 'templatesUri is not valid ');
            throw 'templatesUri is not valid ';
        }
        
     if (!validatestringlength(context.getVariable('templatesUri'), 0, 250)) {
         
        context.setVariable("EH_ErrorDescription", 'templatesUri should be between 1 and 250 characters');
        throw 'templatesUri should be between 1 and 250 characters';
    }
} 

if (context.getVariable('expireEnabled') !== null) {
    if (context.getVariable('expireEnabled').toUpperCase() !== "TRUE") 
    {
        if (context.getVariable('expireEnabled').toUpperCase() !== "FALSE")
        {
            context.setVariable("EH_ErrorDescription", 'Invalid expireEnabled');
            throw 'Invalid expireEnabled';
        }
    }
}

if (context.getVariable('expireDateTime') !== null)
{
     if (!ValidateDateTimeWithOffset(context.getVariable('expireDateTime'))) {
         
        context.setVariable("EH_ErrorDescription", 'Invalid expireDateTime');
        throw 'Invalid expireDateTime';
    }
}

if (context.getVariable('expireAfter') !== null)
{
     if (!ValidateNumbers(context.getVariable('expireAfter'))) {
         
        context.setVariable("EH_ErrorDescription", 'Invalid expireAfter');
        throw 'Invalid expireAfter';
    }
}

if (context.getVariable('userName') !== null)
{
     if (!validatestringlength(context.getVariable('userName'), 0, 50)) {
         
        context.setVariable("EH_ErrorDescription", 'userName should be between 1 and 50 characters');
        throw 'userName should be between 1 and 50 characters';
    }
    if (!isValidNameList(context.getVariable('userName'))) {

        context.setVariable("EH_ErrorDescription", 'userName should not contain special characters');
        throw 'userName should not contain special characters';
    }
}

if (context.getVariable('senderuserId') !== null) 
{
    if (!IsValidGuid(context.getVariable('senderuserId'))) {
        
    context.setVariable("EH_ErrorDescription", 'Invalid sender userId');
    throw 'Invalid sender userId';
    }
}

if (context.getVariable('senderaccountId') !== null) 
{
    if (!IsValidGuid(context.getVariable('senderaccountId'))) {
        
    context.setVariable("EH_ErrorDescription", 'Invalid sender accountId');
    throw 'Invalid sender accountId';
    }
}

if (context.getVariable('email') !== null)
{
     if (!validatestringlength(context.getVariable('email'), 0, 200)) {
         
        context.setVariable("EH_ErrorDescription", 'email should be between 1 and 200 characters');
        throw 'email should be between 1 and 200 characters';
    }
    if (!validateEmailAddress(context.getVariable('email'))) {

        context.setVariable("EH_ErrorDescription", 'Invalid email');
        throw 'Invalid email';
    }
}

if (context.getVariable('creationReason') !== null)
{
    if (context.getVariable('creationReason') !== "")
        {
  
             if (!ValidateLengthInObjList(context.getVariable('creationReason'), 1, 50)) {
                 
                context.setVariable("EH_ErrorDescription", 'creationReason should be between 1 and 50 characters');
                throw 'creationReason should be between 1 and 50 characters';
            }
            if (!ValidateSpclCharInObjList(context.getVariable('creationReason'))) {
        
                context.setVariable("EH_ErrorDescription", 'creationReason should not contain special characters');
                throw 'creationReason should not contain special characters';
            }
        }
}

if (context.getVariable('canSignOffline') !== null) {

 if (!ValidateBooleanInObjList(context.getVariable('canSignOffline'))) {

        context.setVariable("EH_ErrorDescription", 'Invalid canSignOffline');
        throw 'Invalid canSignOffline';
    }
}

if (context.getVariable('isBulkRecipient') !== null) {

 if (!ValidateBooleanInObjList(context.getVariable('isBulkRecipient'))) {

        context.setVariable("EH_ErrorDescription", 'Invalid isBulkRecipient');
        throw 'Invalid isBulkRecipient';
    }
}

if (context.getVariable('requireUploadSignature') !== null) {

 if (!ValidateBooleanInObjList(context.getVariable('requireUploadSignature'))) {

        context.setVariable("EH_ErrorDescription", 'Invalid requireUploadSignature');
        throw 'requireIdLookup requireUploadSignature';
    }
}

if (context.getVariable('name') !== null) {
    
    if (context.getVariable('name') !== "")
    {
         if (!isValidNameList(context.getVariable('name'), 0, 100)) {
             
            context.setVariable("EH_ErrorDescription", 'name should be between 0 and 100 characters');
            throw 'name should be between 0 and 100 characters';
        }
        if (!ValidateSpclCharInObjList(context.getVariable('name'))) {
    
            context.setVariable("EH_ErrorDescription", 'name should not contain special characters');
            throw 'name should not contain special characters';
        }
    }
}

if (context.getVariable('firstName') !== null) {
    
    if (context.getVariable('firstName') !== "")
    {
         if (!ValidateLengthInObjList(context.getVariable('firstName'), 0, 50)) {
             
            context.setVariable("EH_ErrorDescription", 'firstName should be between 0 and 50 characters');
            throw 'firstName should be between 0 and 50 characters';
        }
        if (!isValidNameList(context.getVariable('firstName'))) {
    
            context.setVariable("EH_ErrorDescription", 'firstName should not contain special characters');
            throw 'firstName should not contain special characters';
        }
    }
}

if (context.getVariable('lastName') !== null) {
    
    if (context.getVariable('lastName') !== "")
    {
         if (!ValidateLengthInObjList(context.getVariable('lastName'), 0, 50)) {
             
            context.setVariable("EH_ErrorDescription", 'lastName should be between 0 and 50 characters');
            throw 'lastName should be between 0 and 50 characters';
        }
        if (!isValidNameList(context.getVariable('lastName'))) {
    
            context.setVariable("EH_ErrorDescription", 'lastName should not contain special characters');
            throw 'lastName should not contain special characters';
        }
    }
}

if (context.getVariable('signersemail') !== null)
{
     if (!validatestringlength(context.getVariable('signersemail'), 0, 200)) {
         
        context.setVariable("EH_ErrorDescription", 'signers email should be between 1 and 200 characters');
        throw 'signers email should be between 1 and 200 characters';
    }
    if (!isValidValueEmail(context.getVariable('signersemail'))) {

        context.setVariable("EH_ErrorDescription", 'Invalid signers email');
        throw 'Invalid signers email';
    }
}

if (context.getVariable('recipientId') !== null)
{
     if (!ValidateNumbersInObjList(context.getVariable('recipientId'))) {
         
        context.setVariable("EH_ErrorDescription", 'Invalid recipientId');
        throw 'Invalid recipientId';
    }
}

if (context.getVariable('recipientIdGuid') !== null) {
    
    if (!ValidateGuidInObjList(context.getVariable('recipientIdGuid'))) {
        
    context.setVariable("EH_ErrorDescription", 'Invalid recipientIdGuid');
    throw 'Invalid recipientIdGuid';
    }
}

if (context.getVariable('requireIdLookup') !== null) {
    
 if (!ValidateBooleanInObjList(context.getVariable('requireIdLookup'))) {

        context.setVariable("EH_ErrorDescription", 'Invalid requireIdLookup');
        throw 'Invalid requireIdLookup';
    }
}

if (context.getVariable('signersuserId') !== null) {
    
    if (!ValidateGuidInObjList(context.getVariable('signersuserId'))) {
        
    context.setVariable("EH_ErrorDescription", 'Invalid signers userId');
    throw 'Invalid signers userId';
    }
}

if (context.getVariable('routingOrder') !== null)
{
     if (!ValidateNumbersInObjList(context.getVariable('routingOrder'))) {
         
        context.setVariable("EH_ErrorDescription", 'Invalid routingOrder');
        throw 'Invalid routingOrder';
    }
}

if (context.getVariable('signersstatus') !== null)
{
     if (!validatestringlength(context.getVariable('signersstatus'), 0, 50)) {
         
        context.setVariable("EH_ErrorDescription", 'signers status should be between 1 and 50 characters');
        throw 'signers status should be between 1 and 50 characters';
    }
    if (!isValidNameList(context.getVariable('signersstatus'))) {

        context.setVariable("EH_ErrorDescription", 'signers status should not contain special characters');
        throw 'signers status should not contain special characters';
    }
}

if (context.getVariable('completedCount') !== null)
{
     if (!ValidateNumbersInObjList(context.getVariable('completedCount'))) {
         
        context.setVariable("EH_ErrorDescription", 'Invalid completedCount');
        throw 'Invalid completedCount';
    }
}

if (context.getVariable('signedDateTime'))
{
    print("type", (typeof(context.getVariable('signedDateTime'))));
     if (!ValidateDateTimeInObjList(context.getVariable('signedDateTime'))) {
         
        context.setVariable("EH_ErrorDescription", 'Invalid signedDateTime');
        throw 'Invalid signedDateTime';
    }
}

if (context.getVariable('signersdeliveredDateTime'))
{
     if (!ValidateDateTimeInObjList(context.getVariable('signersdeliveredDateTime'))) {
         
        context.setVariable("EH_ErrorDescription", 'Invalid signersdeliveredDateTime');
        throw 'Invalid signersdeliveredDateTime';
    }
}

if (context.getVariable('signersentDateTime'))
{
     if (!ValidateDateTimeInObjList(context.getVariable('signersentDateTime'))) {
         
        context.setVariable("EH_ErrorDescription", 'Invalid signersentDateTime');
        throw 'Invalid signersentDateTime';
    }
}

if (context.getVariable('deliveryMethod') !== null)
{
     if (!ValidateLengthInObjList(context.getVariable('deliveryMethod'), 0, 5)) {
         
        context.setVariable("EH_ErrorDescription", 'deliveryMethod should be between 1 and 5 characters');
        throw 'deliveryMethod should be between 1 and 5 characters';
    }
    if (!isValidNameList(context.getVariable('deliveryMethod'))) {

        context.setVariable("EH_ErrorDescription", 'deliveryMethod should not contain special characters');
        throw 'deliveryMethod should not contain special characters';
    }
    if (!isValidEmailContactType(context.getVariable('deliveryMethod').toUpperCase()))
        {
            context.setVariable("EH_ErrorDescription", 'Invalid deliveryMethod');
            throw 'Invalid deliveryMethod';
        }
}

if (context.getVariable('recipientType') !== null)
{
     if (!ValidateLengthInObjList(context.getVariable('recipientType'), 0, 6)) {
         
        context.setVariable("EH_ErrorDescription", 'recipientType should be between 1 and 6 characters');
        throw 'recipientType should be between 1 and 6 characters';
    }
    if (!isValidNameList(context.getVariable('recipientType'))) {

        context.setVariable("EH_ErrorDescription", 'recipientType should not contain special characters');
        throw 'recipientType should not contain special characters';
    }
    if (!isValidRecipientType(context.getVariable('recipientType').toUpperCase()))
        {
            context.setVariable("EH_ErrorDescription", 'Invalid recipientType');
            throw 'Invalid recipientType';
        }
}

if (context.getVariable('recipientCount') !== null)
{
     if (!ValidateNumbers(context.getVariable('recipientCount'))) {
         
        context.setVariable("EH_ErrorDescription", 'Invalid recipientCount');
        throw 'Invalid recipientCount';
    }
}

if (context.getVariable('currentRoutingOrder') !== null)
{
     if (!ValidateNumbers(context.getVariable('currentRoutingOrder'))) {
         
        context.setVariable("EH_ErrorDescription", 'Invalid currentRoutingOrder');
        throw 'Invalid currentRoutingOrder';
    }
}

if (context.getVariable('purgeState') !== null)
{
     if (!validatestringlength(context.getVariable('purgeState'), 0, 20)) {
         
        context.setVariable("EH_ErrorDescription", 'purgeState should be between 1 and 20 characters');
        throw 'purgeState should be between 1 and 20 characters';
    }
    if (!isValidNameList(context.getVariable('purgeState'))) {

        context.setVariable("EH_ErrorDescription", 'purgeState should not contain special characters');
        throw 'purgeState should not contain special characters';
    }
}

if (context.getVariable('envelopeIdStamping') !== null) {
    if (context.getVariable('envelopeIdStamping').toUpperCase() !== "TRUE") 
    {
        if (context.getVariable('envelopeIdStamping').toUpperCase() !== "FALSE")
        {
            context.setVariable("EH_ErrorDescription", 'Invalid envelopeIdStamping');
            throw 'Invalid envelopeIdStamping';
        }
    }
}

if (context.getVariable('is21CFRPart11') !== null) {
    if (context.getVariable('is21CFRPart11').toUpperCase() !== "TRUE") 
    {
        if (context.getVariable('is21CFRPart11').toUpperCase() !== "FALSE")
        {
            context.setVariable("EH_ErrorDescription", 'Invalid is21CFRPart11');
            throw 'Invalid is21CFRPart11';
        }
    }
}

if (context.getVariable('signerCanSignOnMobile') !== null) {
    if (context.getVariable('signerCanSignOnMobile').toUpperCase() !== "TRUE") 
    {
        if (context.getVariable('signerCanSignOnMobile').toUpperCase() !== "FALSE")
        {
            context.setVariable("EH_ErrorDescription", 'Invalid signerCanSignOnMobile');
            throw 'Invalid signerCanSignOnMobile';
        }
    }
}

if (context.getVariable('autoNavigation') !== null) {
    if (context.getVariable('autoNavigation').toUpperCase() !== "TRUE") 
    {
        if (context.getVariable('autoNavigation').toUpperCase() !== "FALSE")
        {
            context.setVariable("EH_ErrorDescription", 'Invalid autoNavigation');
            throw 'Invalid autoNavigation';
        }
    }
}

if (context.getVariable('isSignatureProviderEnvelope') !== null) {
    if (context.getVariable('isSignatureProviderEnvelope').toUpperCase() !== "TRUE") 
    {
        if (context.getVariable('isSignatureProviderEnvelope').toUpperCase() !== "FALSE")
        {
            context.setVariable("EH_ErrorDescription", 'Invalid isSignatureProviderEnvelope');
            throw 'Invalid isSignatureProviderEnvelope';
        }
    }
}

if (context.getVariable('hasFormDataChanged') !== null) {
    if (context.getVariable('hasFormDataChanged').toUpperCase() !== "TRUE") 
    {
        if (context.getVariable('hasFormDataChanged').toUpperCase() !== "FALSE")
        {
            context.setVariable("EH_ErrorDescription", 'Invalid hasFormDataChanged');
            throw 'Invalid hasFormDataChanged';
        }
    }
}

if (context.getVariable('allowComments') !== null) {
    if (context.getVariable('allowComments').toUpperCase() !== "TRUE") 
    {
        if (context.getVariable('allowComments').toUpperCase() !== "FALSE")
        {
            context.setVariable("EH_ErrorDescription", 'Invalid allowComments');
            throw 'Invalid allowComments';
        }
    }
}

if (context.getVariable('hasComments') !== null) {
    if (context.getVariable('hasComments').toUpperCase() !== "TRUE") 
    {
        if (context.getVariable('hasComments').toUpperCase() !== "FALSE")
        {
            context.setVariable("EH_ErrorDescription", 'Invalid hasComments');
            throw 'Invalid hasComments';
        }
    }
}

if (context.getVariable('allowViewHistory') !== null) {
    if (context.getVariable('allowViewHistory').toUpperCase() !== "TRUE") 
    {
        if (context.getVariable('allowViewHistory').toUpperCase() !== "FALSE")
        {
            context.setVariable("EH_ErrorDescription", 'Invalid allowViewHistory');
            throw 'Invalid allowViewHistory';
        }
    }
}

if (context.getVariable('allowAdvancedCorrect') !== null) {
    if (context.getVariable('allowAdvancedCorrect').toUpperCase() !== "TRUE") 
    {
        if (context.getVariable('allowAdvancedCorrect').toUpperCase() !== "FALSE")
        {
            context.setVariable("EH_ErrorDescription", 'Invalid allowAdvancedCorrect');
            throw 'Invalid allowAdvancedCorrect';
        }
    }
}

if (context.getVariable('enableSignWithNotary') !== null) {
    if (context.getVariable('enableSignWithNotary').toUpperCase() !== "TRUE") 
    {
        if (context.getVariable('enableSignWithNotary').toUpperCase() !== "FALSE")
        {
            context.setVariable("EH_ErrorDescription", 'Invalid enableSignWithNotary');
            throw 'Invalid enableSignWithNotary';
        }
    }
}

if (context.getVariable('allowCorrect') !== null) {
    if (context.getVariable('allowCorrect').toUpperCase() !== "TRUE") 
    {
        if (context.getVariable('allowCorrect').toUpperCase() !== "FALSE")
        {
            context.setVariable("EH_ErrorDescription", 'Invalid allowCorrect');
            throw 'Invalid allowCorrect';
        }
    }
}

if (context.getVariable('anySigner') !== null)
{
     if (!validatestringlength(context.getVariable('anySigner'), 0, 50)) {
         
        context.setVariable("EH_ErrorDescription", 'anySigner should be between 1 and 50 characters');
        throw 'anySigner should be between 1 and 50 characters';
    }
    if (!isValidNameList(context.getVariable('anySigner'))) {

        context.setVariable("EH_ErrorDescription", 'anySigner should not contain special characters');
        throw 'anySigner should not contain special characters';
    }
}

if (context.getVariable('envelopeLocation') !== null)
{
     if (!validatestringlength(context.getVariable('envelopeLocation'), 0, 50)) {
         
        context.setVariable("EH_ErrorDescription", 'anySigenvelopeLocationer should be between 1 and 50 characters');
        throw 'envelopeLocation should be between 1 and 50 characters';
    }
    if (!ValidateErrorMessage(context.getVariable('envelopeLocation'))) {

        context.setVariable("EH_ErrorDescription", 'envelopeLocation should not contain special characters');
        throw 'envelopeLocation should not contain special characters';
    }
}

if (context.getVariable('isDynamicEnvelope') !== null) {
    if (context.getVariable('isDynamicEnvelope').toUpperCase() !== "TRUE") 
    {
        if (context.getVariable('isDynamicEnvelope').toUpperCase() !== "FALSE")
        {
            context.setVariable("EH_ErrorDescription", 'Invalid isDynamicEnvelope');
            throw 'Invalid isDynamicEnvelope';
        }
    }
}

if (context.getVariable('burnDefaultTabData') !== null) {
    if (context.getVariable('burnDefaultTabData').toUpperCase() !== "TRUE") 
    {
        if (context.getVariable('burnDefaultTabData').toUpperCase() !== "FALSE")
        {
            context.setVariable("EH_ErrorDescription", 'Invalid burnDefaultTabData');
            throw 'Invalid burnDefaultTabData';
        }
    }
}

if (context.getVariable('fieldId') !== null)
{
     if (!ValidateNumbersInObjList(context.getVariable('fieldId'))) {
         
        context.setVariable("EH_ErrorDescription", 'Invalid fieldId');
        throw 'Invalid fieldId';
    }
}

if (context.getVariable('customFieldsname') !== null) {
     if (!validatestringlength(context.getVariable('customFieldsname'), 0, 100)) {
         
        context.setVariable("EH_ErrorDescription", 'customFieldsname should be between 1 and 100 characters');
        throw 'customFieldsname should be between 1 and 100 characters';
    }
    if (!isValidNameList(context.getVariable('customFieldsname'))) {

        context.setVariable("EH_ErrorDescription", 'customFieldsname should not contain special characters');
        throw 'customFieldsname should not contain special characters';
    }
}


if (context.getVariable('show') !== null) {
    
     if (!ValidateBooleanInObjList(context.getVariable('show'))) {
         
        context.setVariable("EH_ErrorDescription", 'Invalid show');
        throw 'Invalid show';
    }
}

if (context.getVariable('required') !== null) {
    
     if (!ValidateBooleanInObjList(context.getVariable('required'))) {
         
        context.setVariable("EH_ErrorDescription", 'Invalid required');
        throw 'Invalid required';
    }
}

if (context.getVariable('value') !== null && context.getVariable('value') !== "") 
{
     if (!ValidateLengthInObjList(context.getVariable('value'), 0, 100)) {
         
        context.setVariable("EH_ErrorDescription", 'value should be between 1 and 100 characters');
        throw 'value should be between 1 and 100 characters';
    }
    if (!ValidateSpclCharInObjList(context.getVariable('value'))) {

        context.setVariable("EH_ErrorDescription", 'value should not contain special characters');
        throw 'value should not contain special characters';
    }
}